package dao.usuario;

import dao.IDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.entidade.Usuario;
import util.ConnectionFactory;

public class CadastrarUsuarioDAO implements IDAO<Usuario> {

    @Override
    public void executar(Usuario usuario) throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement(
                "INSERT INTO usuarios (nome, email, senha, tipo, ativo) VALUES (?,?,?,?,?)"
        );
        cmd.setString(1, usuario.getNome());
        cmd.setString(2, usuario.getEmail());
        cmd.setString(3, usuario.getSenha());
        cmd.setString(4, usuario.getTipo().name());
        cmd.setBoolean(5, usuario.isAtivo());
        cmd.execute();
        con.close();
    }
}
