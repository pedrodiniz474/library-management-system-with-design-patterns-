package dao.usuario;

import dao.IConsultar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.entidade.Usuario;
import model.enums.TipoUsuario;
import util.ConnectionFactory;

public class ConsultarUsuarioDAO implements IConsultar<Usuario> {

    @Override
    public Usuario consultarPorId(int id) throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement(
                "SELECT * FROM usuarios WHERE id = ?"
        );
        cmd.setInt(1, id);
        ResultSet rs = cmd.executeQuery();
        Usuario usuario = null;
        if (rs.next()) {
            usuario = montar(rs);
        }
        con.close();
        return usuario;
    }

    @Override
    public List<Usuario> consultarTodos() throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement("SELECT * FROM usuarios");
        ResultSet rs = cmd.executeQuery();
        List<Usuario> lista = new ArrayList<>();
        while (rs.next()) {
            lista.add(montar(rs));
        }
        con.close();
        return lista;
    }

    public Usuario consultarPorEmailSenha(String email, String senha) throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement(
                "SELECT * FROM usuarios WHERE email = ? AND senha = ? AND ativo = true"
        );
        cmd.setString(1, email);
        cmd.setString(2, senha);
        ResultSet rs = cmd.executeQuery();
        Usuario usuario = null;
        if (rs.next()) {
            usuario = montar(rs);
        }
        con.close();
        return usuario;
    }

    private Usuario montar(ResultSet rs) throws SQLException {
        return new Usuario(
                rs.getInt("id"),
                rs.getString("nome"),
                rs.getString("email"),
                rs.getString("senha"),
                TipoUsuario.valueOf(rs.getString("tipo")),
                rs.getBoolean("ativo")
        );
    }
}
