package dao.usuario;

import dao.IDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.entidade.Usuario;
import util.ConnectionFactory;

public class AtualizarUsuarioDAO implements IDAO<Usuario> {

    @Override
    public void executar(Usuario usuario) throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement(
                "UPDATE usuarios SET nome=?, email=?, senha=?, tipo=?, ativo=? WHERE id=?"
        );
        cmd.setString(1, usuario.getNome());
        cmd.setString(2, usuario.getEmail());
        cmd.setString(3, usuario.getSenha());
        cmd.setString(4, usuario.getTipo().name());
        cmd.setBoolean(5, usuario.isAtivo());
        cmd.setInt(6, usuario.getId());
        cmd.execute();
        con.close();
    }
}
