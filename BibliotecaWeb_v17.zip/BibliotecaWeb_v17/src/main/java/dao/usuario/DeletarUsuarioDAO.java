package dao.usuario;

import dao.IDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.entidade.Usuario;
import util.ConnectionFactory;

public class DeletarUsuarioDAO implements IDAO<Usuario> {

    @Override
    public void executar(Usuario usuario) throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement(
                "DELETE FROM usuarios WHERE id = ?"
        );
        cmd.setInt(1, usuario.getId());
        cmd.execute();
        con.close();
    }
}
