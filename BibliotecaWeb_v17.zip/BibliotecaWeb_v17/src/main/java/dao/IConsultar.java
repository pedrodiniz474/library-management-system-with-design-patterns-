package dao;

import java.sql.SQLException;
import java.util.List;

public interface IConsultar<T> {
    T consultarPorId(int id) throws SQLException;
    List<T> consultarTodos() throws SQLException;
}
