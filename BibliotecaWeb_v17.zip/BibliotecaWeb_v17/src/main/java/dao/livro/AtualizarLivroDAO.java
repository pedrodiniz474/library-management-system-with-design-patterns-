package dao.livro;

import dao.IDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.entidade.Livro;
import util.ConnectionFactory;

public class AtualizarLivroDAO implements IDAO<Livro> {

    @Override
    public void executar(Livro livro) throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement(
                "UPDATE livros SET titulo=?, autor=?, editora=?, isbn=?, genero=?, "
                + "ano_publicacao=?, numero_paginas=?, idioma=?, preco=?, quantidade=?, status=? "
                + "WHERE id=?"
        );
        cmd.setString(1, livro.getTitulo());
        cmd.setString(2, livro.getAutor());
        cmd.setString(3, livro.getEditora());
        cmd.setString(4, livro.getIsbn());
        cmd.setString(5, livro.getGenero());
        cmd.setInt(6, livro.getAnoPublicacao());
        cmd.setInt(7, livro.getNumeroPaginas());
        cmd.setString(8, livro.getIdioma());
        cmd.setDouble(9, livro.getPreco());
        cmd.setInt(10, livro.getQuantidade());
        cmd.setString(11, livro.getStatus().name());
        cmd.setInt(12, livro.getId());
        cmd.execute();
        con.close();
    }
}
