package dao.livro;

import dao.IDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.entidade.Livro;
import util.ConnectionFactory;

public class DeletarLivroDAO implements IDAO<Livro> {

    @Override
    public void executar(Livro livro) throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        try {
            con.setAutoCommit(false);
            PreparedStatement cmdEmp = con.prepareStatement(
                    "DELETE FROM emprestimos WHERE id_livro = ?"
            );
            cmdEmp.setInt(1, livro.getId());
            cmdEmp.execute();

            PreparedStatement cmdLivro = con.prepareStatement(
                    "DELETE FROM livros WHERE id = ?"
            );
            cmdLivro.setInt(1, livro.getId());
            cmdLivro.execute();

            con.commit();
        } catch (SQLException ex) {
            con.rollback();
            throw ex;
        } finally {
            con.setAutoCommit(true);
            con.close();
        }
    }
}
