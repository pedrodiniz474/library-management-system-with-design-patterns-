package dao.livro;

import dao.IConsultar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.entidade.Livro;
import model.enums.StatusLivro;
import util.ConnectionFactory;

public class ConsultarLivroDAO implements IConsultar<Livro> {

    @Override
    public Livro consultarPorId(int id) throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement("SELECT * FROM livros WHERE id = ?");
        cmd.setInt(1, id);
        ResultSet rs = cmd.executeQuery();
        Livro livro = null;
        if (rs.next()) {
            livro = montar(rs);
        }
        con.close();
        return livro;
    }

    @Override
    public List<Livro> consultarTodos() throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement("SELECT * FROM livros");
        ResultSet rs = cmd.executeQuery();
        List<Livro> lista = new ArrayList<>();
        while (rs.next()) {
            lista.add(montar(rs));
        }
        con.close();
        return lista;
    }

    private Livro montar(ResultSet rs) throws SQLException {
        return new Livro.LivroBuilder()
                .comId(rs.getInt("id"))
                .comTitulo(rs.getString("titulo"))
                .comAutor(rs.getString("autor"))
                .comEditora(rs.getString("editora"))
                .comIsbn(rs.getString("isbn"))
                .comGenero(rs.getString("genero"))
                .comAnoPublicacao(rs.getInt("ano_publicacao"))
                .comNumeroPaginas(rs.getInt("numero_paginas"))
                .comIdioma(rs.getString("idioma"))
                .comPreco(rs.getDouble("preco"))
                .comQuantidade(rs.getInt("quantidade"))
                .comStatus(StatusLivro.valueOf(rs.getString("status")))
                .build();
    }
}
