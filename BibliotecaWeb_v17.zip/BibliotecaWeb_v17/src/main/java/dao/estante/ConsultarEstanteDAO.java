package dao.estante;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import model.entidade.Estante;
import model.entidade.EstanteAventura;
import model.entidade.EstanteFiccao;
import model.entidade.EstanteRomance;
import model.entidade.EstanteTerror;
import model.entidade.Livro;
import model.enums.StatusLivro;
import util.ConnectionFactory;

public class ConsultarEstanteDAO {

    private String normalizarGenero(String genero) {
        if (genero == null) {
            return "Ficcao";
        }
        String g = genero.replaceAll("[^A-Za-z]", "").toLowerCase();
        if (g.startsWith("fic")) {
            return "Ficcao";
        }
        if (g.equals("romance")) {
            return "Romance";
        }
        if (g.equals("terror")) {
            return "Terror";
        }
        if (g.equals("aventura")) {
            return "Aventura";
        }
        return genero;
    }

    private Estante instanciarEstante(String genero) {
        switch (normalizarGenero(genero)) {
            case "Ficcao":
                return new EstanteFiccao();
            case "Romance":
                return new EstanteRomance();
            case "Terror":
                return new EstanteTerror();
            case "Aventura":
                return new EstanteAventura();
            default:
                return new EstanteFiccao();
        }
    }

    public List<Estante> consultarTodas() throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement(
                "SELECT e.id, e.genero, "
                + "l.id as l_id, l.titulo, l.autor, l.editora, l.isbn, l.genero as l_genero, "
                + "l.ano_publicacao, l.numero_paginas, l.idioma, l.preco, l.quantidade, l.status "
                + "FROM estantes e "
                + "LEFT JOIN livros l ON REGEXP_REPLACE(LOWER(l.genero), '[^a-z]', '') = "
                + "REGEXP_REPLACE(LOWER(e.genero), '[^a-z]', '')"
        );
        ResultSet rs = cmd.executeQuery();
        List<Estante> lista = new ArrayList<>();
        Estante atual = null;

        while (rs.next()) {
            int idEstante = rs.getInt("id");
            if (atual == null || atual.getId() != idEstante) {
                atual = instanciarEstante(rs.getString("genero"));
                atual.setId(idEstante);
                lista.add(atual);
            }
            if (rs.getInt("l_id") != 0) {
                atual.adicionarLivro(montarLivro(rs));
            }
        }
        con.close();

        Map<String, Estante> mapa = new LinkedHashMap<>();
        for (Estante e : lista) {
            String chave = normalizarGenero(e.getGenero());
            if (mapa.containsKey(chave)) {
                for (Livro lv : e.getLivros()) {
                    mapa.get(chave).adicionarLivro(lv);
                }
            } else {
                mapa.put(chave, e);
            }
        }
        return new ArrayList<>(mapa.values());
    }

    public Estante consultarPorGenero(String genero) throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement(
                "SELECT e.id, e.genero, "
                + "l.id as l_id, l.titulo, l.autor, l.editora, l.isbn, l.genero as l_genero, "
                + "l.ano_publicacao, l.numero_paginas, l.idioma, l.preco, l.quantidade, l.status "
                + "FROM estantes e "
                + "LEFT JOIN livros l ON l.genero = e.genero "
                + "WHERE e.genero = ?"
        );
        cmd.setString(1, genero);
        ResultSet rs = cmd.executeQuery();
        Estante estante = null;

        while (rs.next()) {
            if (estante == null) {
                estante = instanciarEstante(rs.getString("genero"));
                estante.setId(rs.getInt("id"));
            }
            if (rs.getInt("l_id") != 0) {
                estante.adicionarLivro(montarLivro(rs));
            }
        }
        con.close();
        return estante;
    }

    private Livro montarLivro(ResultSet rs) throws SQLException {
        return new Livro.LivroBuilder()
                .comId(rs.getInt("l_id"))
                .comTitulo(rs.getString("titulo"))
                .comAutor(rs.getString("autor"))
                .comEditora(rs.getString("editora"))
                .comIsbn(rs.getString("isbn"))
                .comGenero(rs.getString("l_genero"))
                .comAnoPublicacao(rs.getInt("ano_publicacao"))
                .comNumeroPaginas(rs.getInt("numero_paginas"))
                .comIdioma(rs.getString("idioma"))
                .comPreco(rs.getDouble("preco"))
                .comQuantidade(rs.getInt("quantidade"))
                .comStatus(StatusLivro.valueOf(rs.getString("status")))
                .build();
    }
}
