package dao.emprestimo;

import dao.IDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.entidade.Emprestimo;
import util.ConnectionFactory;

public class DeletarEmprestimoDAO implements IDAO<Emprestimo> {

    @Override
    public void executar(Emprestimo emp) throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement(
                "DELETE FROM emprestimos WHERE id = ?"
        );
        cmd.setInt(1, emp.getId());
        cmd.execute();
        con.close();
    }
}
