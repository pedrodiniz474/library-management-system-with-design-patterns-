package dao.emprestimo;

import dao.IConsultar;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.entidade.Emprestimo;
import model.entidade.Livro;
import model.entidade.Usuario;
import model.enums.StatusLivro;
import model.enums.TipoUsuario;
import util.ConnectionFactory;

public class ConsultarEmprestimoDAO implements IConsultar<Emprestimo> {

    private static final String SQL_BASE
            = "SELECT e.*, "
            + "u.id as u_id, u.nome, u.email, u.senha, u.tipo, u.ativo, "
            + "l.id as l_id, l.titulo, l.autor, l.editora, l.isbn, l.genero, "
            + "l.ano_publicacao, l.numero_paginas, l.idioma, l.preco, l.quantidade, l.status "
            + "FROM emprestimos e "
            + "JOIN usuarios u ON e.id_usuario = u.id "
            + "JOIN livros l ON e.id_livro = l.id";

    @Override
    public Emprestimo consultarPorId(int id) throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement(SQL_BASE + " WHERE e.id = ?");
        cmd.setInt(1, id);
        ResultSet rs = cmd.executeQuery();
        Emprestimo emp = null;
        if (rs.next()) {
            emp = montar(rs);
        }
        con.close();
        return emp;
    }

    @Override
    public List<Emprestimo> consultarTodos() throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement(SQL_BASE);
        ResultSet rs = cmd.executeQuery();
        List<Emprestimo> lista = new ArrayList<>();
        while (rs.next()) {
            lista.add(montar(rs));
        }
        con.close();
        return lista;
    }

    public static Emprestimo montar(ResultSet rs) throws SQLException {
        Usuario usuario = new Usuario(
                rs.getInt("u_id"),
                rs.getString("nome"),
                rs.getString("email"),
                rs.getString("senha"),
                TipoUsuario.valueOf(rs.getString("tipo")),
                rs.getBoolean("ativo")
        );

        Livro livro = new Livro.LivroBuilder()
                .comId(rs.getInt("l_id"))
                .comTitulo(rs.getString("titulo"))
                .comAutor(rs.getString("autor"))
                .comEditora(rs.getString("editora"))
                .comIsbn(rs.getString("isbn"))
                .comGenero(rs.getString("genero"))
                .comAnoPublicacao(rs.getInt("ano_publicacao"))
                .comNumeroPaginas(rs.getInt("numero_paginas"))
                .comIdioma(rs.getString("idioma"))
                .comPreco(rs.getDouble("preco"))
                .comQuantidade(rs.getInt("quantidade"))
                .comStatus(StatusLivro.valueOf(rs.getString("status")))
                .build();

        Date dataDev = rs.getDate("data_devolucao");

        return new Emprestimo.EmprestimoBuilder()
                .comId(rs.getInt("id"))
                .comUsuario(usuario)
                .comLivro(livro)
                .comDataEmprestimo(rs.getDate("data_emprestimo").toLocalDate())
                .comDataPrevistaDevolucao(rs.getDate("data_prevista_devolucao").toLocalDate())
                .comDataDevolucao(dataDev != null ? dataDev.toLocalDate() : null)
                .build();
    }
}
