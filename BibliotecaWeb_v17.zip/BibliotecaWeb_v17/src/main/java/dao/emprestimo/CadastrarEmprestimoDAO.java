package dao.emprestimo;

import dao.IDAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.entidade.Emprestimo;
import util.ConnectionFactory;

public class CadastrarEmprestimoDAO implements IDAO<Emprestimo> {

    @Override
    public void executar(Emprestimo emp) throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        try {
            con.setAutoCommit(false);

            PreparedStatement cmdEmp = con.prepareStatement(
                    "INSERT INTO emprestimos (id_usuario, id_livro, data_emprestimo, "
                    + "data_prevista_devolucao, data_devolucao) VALUES (?,?,?,?,?)"
            );
            cmdEmp.setInt(1, emp.getUsuario().getId());
            cmdEmp.setInt(2, emp.getLivro().getId());
            cmdEmp.setDate(3, Date.valueOf(emp.getDataEmprestimo()));
            cmdEmp.setDate(4, Date.valueOf(emp.getDataPrevistaDevolucao()));
            cmdEmp.setDate(5, emp.getDataDevolucao() != null
                    ? Date.valueOf(emp.getDataDevolucao()) : null);
            cmdEmp.execute();

            PreparedStatement cmdLivro = con.prepareStatement(
                    "UPDATE livros SET "
                    + "quantidade = quantidade - 1, "
                    + "status = CASE WHEN (quantidade - 1) <= 0 THEN 'EMPRESTADO' ELSE 'DISPONIVEL' END "
                    + "WHERE id = ? AND quantidade > 0"
            );
            cmdLivro.setInt(1, emp.getLivro().getId());
            int linhasAfetadas = cmdLivro.executeUpdate();

            if (linhasAfetadas == 0) {
                con.rollback();
                throw new SQLException("Livro indisponível para empréstimo.");
            }

            con.commit();
        } catch (SQLException ex) {
            con.rollback();
            throw ex;
        } finally {
            con.setAutoCommit(true);
            con.close();
        }
    }
}
