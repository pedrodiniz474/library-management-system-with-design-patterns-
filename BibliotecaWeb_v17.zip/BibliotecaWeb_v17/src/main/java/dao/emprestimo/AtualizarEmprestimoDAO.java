package dao.emprestimo;

import dao.IDAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.entidade.Emprestimo;
import util.ConnectionFactory;

public class AtualizarEmprestimoDAO implements IDAO<Emprestimo> {

    @Override
    public void executar(Emprestimo emp) throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement cmd = con.prepareStatement(
                "UPDATE emprestimos SET id_usuario=?, id_livro=?, data_emprestimo=?, "
                + "data_prevista_devolucao=?, data_devolucao=? WHERE id=?"
        );
        cmd.setInt(1, emp.getUsuario().getId());
        cmd.setInt(2, emp.getLivro().getId());
        cmd.setDate(3, Date.valueOf(emp.getDataEmprestimo()));
        cmd.setDate(4, Date.valueOf(emp.getDataPrevistaDevolucao()));
        cmd.setDate(5, emp.getDataDevolucao() != null
                ? Date.valueOf(emp.getDataDevolucao()) : null);
        cmd.setInt(6, emp.getId());
        cmd.execute();
        con.close();
    }
}
