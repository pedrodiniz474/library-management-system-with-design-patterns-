package dao.emprestimo;

import dao.IDAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import model.entidade.Emprestimo;
import util.ConnectionFactory;

public class RegistrarDevolucaoDAO implements IDAO<Emprestimo> {

    @Override
    public void executar(Emprestimo emp) throws SQLException {
        Connection con = ConnectionFactory.getConnection();
        try {
            con.setAutoCommit(false);

            PreparedStatement cmdEmp = con.prepareStatement(
                    "UPDATE emprestimos SET data_devolucao=? WHERE id=?"
            );
            cmdEmp.setDate(1, Date.valueOf(emp.getDataDevolucao()));
            cmdEmp.setInt(2, emp.getId());
            cmdEmp.executeUpdate();

            PreparedStatement cmdLivro = con.prepareStatement(
                    "UPDATE livros SET quantidade = quantidade + 1, status = 'DISPONIVEL' WHERE id = ?"
            );
            cmdLivro.setInt(1, emp.getLivro().getId());
            cmdLivro.executeUpdate();

            con.commit();
        } catch (SQLException ex) {
            con.rollback();
            throw ex;
        } finally {
            con.setAutoCommit(true);
            con.close();
        }
    }
}
