package command;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import javax.servlet.http.HttpServletRequest;

public class CommandFactory {

    private final String packagePath;
    private final String sufixoAction;
    private final HttpServletRequest request;

    public CommandFactory(String packagePath, String sufixoAction, HttpServletRequest request) {
        this.packagePath = packagePath;
        this.sufixoAction = sufixoAction;
        this.request = request;
    }

    public ICommand getCommand(String acao) {
        try {
            String caminhoCompleto = packagePath + acao + sufixoAction;

            Class<?> classeAction = Class.forName(caminhoCompleto);

            Constructor<?> construtor = classeAction.getConstructor(HttpServletRequest.class);

            return (ICommand) construtor.newInstance(this.request);

        } catch (ClassNotFoundException | IllegalAccessException | IllegalArgumentException
                | InstantiationException | NoSuchMethodException | InvocationTargetException e) {
            System.err.println("Erro ao criar comando via Reflection: " + e.getMessage());
            return null;
        }
    }
}
