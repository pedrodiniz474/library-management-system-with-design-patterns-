package command.emprestimo;

import command.ICommand;
import dao.emprestimo.AtualizarEmprestimoDAO;
import dao.livro.ConsultarLivroDAO;
import dao.usuario.ConsultarUsuarioDAO;
import model.entidade.Emprestimo;
import model.entidade.Livro;
import model.entidade.Usuario;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.time.LocalDate;

public class AtualizarEmprestimoAction implements ICommand {

    private final AtualizarEmprestimoDAO dao;
    private final ConsultarUsuarioDAO consultarUsuDAO;
    private final ConsultarLivroDAO consultarLivDAO;
    private final HttpServletRequest request;

    public AtualizarEmprestimoAction(HttpServletRequest request) {
        this.request = request;
        this.dao = new AtualizarEmprestimoDAO();
        this.consultarUsuDAO = new ConsultarUsuarioDAO();
        this.consultarLivDAO = new ConsultarLivroDAO();
    }

    @Override
    public String executar() throws Exception {
        HttpSession session = request.getSession(false);
        Usuario logado = (Usuario) session.getAttribute("usuarioLogado");
        if (!logado.getTipo().name().equals("ADMIN")) {
            return "home.jsp";
        }
        String msg;
        try {
            int idUsuario = Integer.parseInt(request.getParameter("txtidUsuario"));
            int idLivro = Integer.parseInt(request.getParameter("txtidLivro"));
            LocalDate dataEmp = LocalDate.parse(request.getParameter("txtdataEmprestimo"));
            LocalDate dataPrev = LocalDate.parse(request.getParameter("txtdataPrevista"));
            Usuario usuario = consultarUsuDAO.consultarPorId(idUsuario);
            Livro livro = consultarLivDAO.consultarPorId(idLivro);
            dao.executar(new Emprestimo.EmprestimoBuilder()
                    .comId(Integer.parseInt(request.getParameter("txtid")))
                    .comUsuario(usuario).comLivro(livro)
                    .comDataEmprestimo(dataEmp)
                    .comDataPrevistaDevolucao(dataPrev)
                    .build());
            msg = "Empréstimo atualizado com sucesso.";
        } catch (Exception ex) {
            msg = "Erro ao atualizar: " + ex.getMessage();
        }
        session.setAttribute("msg", msg);
        return "emprestimos.jsp";
    }
}
