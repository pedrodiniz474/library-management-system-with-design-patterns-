package command.emprestimo;

import command.ICommand;
import dao.emprestimo.CadastrarEmprestimoDAO;
import dao.emprestimo.ConsultarEmprestimoDAO;
import dao.livro.ConsultarLivroDAO;
import dao.usuario.ConsultarUsuarioDAO;
import model.entidade.Emprestimo;
import model.entidade.Livro;
import model.entidade.Usuario;
import model.service.multa.ICalculoMulta;
import model.service.multa.MultaBase;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.time.LocalDate;
import java.util.List;

public class CadastrarEmprestimoAction implements ICommand {

    private final CadastrarEmprestimoDAO dao;
    private final ConsultarEmprestimoDAO consultarEmpDAO;
    private final ConsultarUsuarioDAO consultarUsuDAO;
    private final ConsultarLivroDAO consultarLivDAO;
    private final HttpServletRequest request;

    public CadastrarEmprestimoAction(HttpServletRequest request) {
        this.request = request;
        this.dao = new CadastrarEmprestimoDAO();
        this.consultarEmpDAO = new ConsultarEmprestimoDAO();
        this.consultarUsuDAO = new ConsultarUsuarioDAO();
        this.consultarLivDAO = new ConsultarLivroDAO();
    }

    @Override
    public String executar() throws Exception {
        HttpSession session = request.getSession(false);
        Usuario logado = (Usuario) session.getAttribute("usuarioLogado");
        boolean isAdmin = logado.getTipo().name().equals("ADMIN");
        String msg;
        try {
            int idUsuario = Integer.parseInt(request.getParameter("txtidUsuario"));
            int idLivro = Integer.parseInt(request.getParameter("txtidLivro"));
            LocalDate dataEmp = LocalDate.now();
            LocalDate dataPrev = dataEmp.plusDays(15);

            Usuario usuario = consultarUsuDAO.consultarPorId(idUsuario);
            Livro livro = consultarLivDAO.consultarPorId(idLivro);

            if (usuario == null) {
                msg = "Erro: usuário não encontrado.";
            } else if (livro == null) {
                msg = "Erro: livro não encontrado.";
            } else {
                List<Emprestimo> todos = consultarEmpDAO.consultarTodos();
                ICalculoMulta calculadora = new MultaBase();
                double multaPendente = 0;
                for (Emprestimo e : todos) {
                    if (e.getUsuario().getId() == idUsuario
                            && e.getDataDevolucao() == null
                            && e.calcularDiasAtraso() > 0) {
                        multaPendente += calculadora.calcular(e);
                    }
                }
                if (multaPendente > 0) {
                    msg = "Bloqueado: multa pendente de R$ "
                            + String.format("%.2f", multaPendente) + ".";
                } else {
                    dao.executar(new Emprestimo.EmprestimoBuilder()
                            .comUsuario(usuario).comLivro(livro)
                            .comDataEmprestimo(dataEmp)
                            .comDataPrevistaDevolucao(dataPrev)
                            .build());
                    msg = "Empréstimo realizado! Devolva até " + dataPrev + ".";
                }
            }
        } catch (NumberFormatException ex) {
            msg = "Erro: ID inválido.";
        }
        session.setAttribute("msg", msg);
        return isAdmin ? "emprestimos.jsp" : "home.jsp";
    }
}
