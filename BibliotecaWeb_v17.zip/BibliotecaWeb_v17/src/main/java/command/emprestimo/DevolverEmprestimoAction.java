package command.emprestimo;

import command.ICommand;
import dao.emprestimo.ConsultarEmprestimoDAO;
import dao.emprestimo.RegistrarDevolucaoDAO;
import model.entidade.Emprestimo;
import model.entidade.Usuario;
import model.service.multa.ICalculoMulta;
import model.service.multa.MultaAtrasoExtendido;
import model.service.multa.MultaBase;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.time.LocalDate;

public class DevolverEmprestimoAction implements ICommand {

    private static final int LIMITE_DIAS_ATRASO_EXTENDIDO = 7;

    private final ConsultarEmprestimoDAO consultarDAO;
    private final RegistrarDevolucaoDAO devolucaoDAO;
    private final HttpServletRequest request;

    public DevolverEmprestimoAction(HttpServletRequest request) {
        this.request = request;
        this.consultarDAO = new ConsultarEmprestimoDAO();
        this.devolucaoDAO = new RegistrarDevolucaoDAO();
    }

    @Override
    public String executar() throws Exception {
        HttpSession session = request.getSession(false);
        Usuario logado = (Usuario) session.getAttribute("usuarioLogado");
        boolean isAdmin = logado.getTipo().name().equals("ADMIN");
        String msg;
        try {
            int id = Integer.parseInt(request.getParameter("txtid"));
            Emprestimo emp = consultarDAO.consultarPorId(id);
            Emprestimo empDevolvido = new Emprestimo.EmprestimoBuilder()
                    .comId(emp.getId()).comUsuario(emp.getUsuario()).comLivro(emp.getLivro())
                    .comDataEmprestimo(emp.getDataEmprestimo())
                    .comDataPrevistaDevolucao(emp.getDataPrevistaDevolucao())
                    .comDataDevolucao(LocalDate.now())
                    .build();
            devolucaoDAO.executar(empDevolvido);

            int diasAtraso = empDevolvido.calcularDiasAtraso();
            if (diasAtraso > 0) {
                ICalculoMulta calculo = new MultaBase();
                if (diasAtraso > LIMITE_DIAS_ATRASO_EXTENDIDO) {
                    calculo = new MultaAtrasoExtendido(calculo);
                }
                msg = "Devolução com " + diasAtraso + " dia(s) de atraso. "
                        + calculo.getDescricao() + ". Total: R$ "
                        + String.format("%.2f", calculo.calcular(empDevolvido));
            } else {
                msg = "Devolução registrada no prazo. Sem multa.";
            }
        } catch (NumberFormatException ex) {
            msg = "Erro: ID inválido.";
        }
        session.setAttribute("msg", msg);
        return isAdmin ? "emprestimos.jsp" : "home.jsp";
    }
}
