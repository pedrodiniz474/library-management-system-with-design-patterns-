package command.emprestimo;

import command.ICommand;
import dao.emprestimo.DeletarEmprestimoDAO;
import model.entidade.Emprestimo;
import model.entidade.Usuario;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class DeletarEmprestimoAction implements ICommand {

    private final DeletarEmprestimoDAO dao;
    private final HttpServletRequest request;

    public DeletarEmprestimoAction(HttpServletRequest request) {
        this.request = request;
        this.dao = new DeletarEmprestimoDAO();
    }

    @Override
    public String executar() throws Exception {
        HttpSession session = request.getSession(false);
        Usuario logado = (Usuario) session.getAttribute("usuarioLogado");
        if (!logado.getTipo().name().equals("ADMIN")) {
            return "home.jsp";
        }
        String msg;
        try {
            Emprestimo emp = new Emprestimo.EmprestimoBuilder()
                    .comId(Integer.parseInt(request.getParameter("txtid")))
                    .build();
            dao.executar(emp);
            msg = "Empréstimo excluído com sucesso.";
        } catch (Exception ex) {
            msg = "Erro ao excluir: " + ex.getMessage();
        }
        session.setAttribute("msg", msg);
        return "emprestimos.jsp";
    }
}
