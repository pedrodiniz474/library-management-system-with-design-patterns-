package command.usuario;

import command.ICommand;
import dao.usuario.CadastrarUsuarioDAO;
import model.entidade.Usuario;
import model.enums.TipoUsuario;
import util.HashUtil;
import javax.servlet.http.HttpServletRequest;

public class CadastrarUsuarioAction implements ICommand {

    private final CadastrarUsuarioDAO dao;
    private final HttpServletRequest request;

    public CadastrarUsuarioAction(HttpServletRequest request) {
        this.request = request;
        this.dao = new CadastrarUsuarioDAO();
    }

    @Override
    public String executar() throws Exception {
        String msg;
        try {
            String senhaHash = HashUtil.sha256(request.getParameter("txtsenha").trim());
            Usuario usuario = new Usuario(0,
                    request.getParameter("txtnome"),
                    request.getParameter("txtemail"),
                    senhaHash,
                    TipoUsuario.valueOf(request.getParameter("seltipo")),
                    true
            );
            dao.executar(usuario);
            msg = "Usuário cadastrado com sucesso.";
        } catch (Exception ex) {
            msg = "Erro ao cadastrar: " + ex.getMessage();
        }
        request.getSession().setAttribute("msg", msg);
        return "usuarios.jsp";
    }
}
