package command.usuario;

import command.ICommand;
import dao.usuario.DeletarUsuarioDAO;
import model.entidade.Usuario;
import javax.servlet.http.HttpServletRequest;

public class DeletarUsuarioAction implements ICommand {

    private final DeletarUsuarioDAO dao;
    private final HttpServletRequest request;

    public DeletarUsuarioAction(HttpServletRequest request) {
        this.request = request;
        this.dao = new DeletarUsuarioDAO();
    }

    @Override
    public String executar() throws Exception {
        String msg;
        try {
            Usuario usuario = new Usuario();
            usuario.setId(Integer.parseInt(request.getParameter("txtid")));
            dao.executar(usuario);
            msg = "Usuário deletado com sucesso.";
        } catch (Exception ex) {
            msg = "Erro ao deletar: " + ex.getMessage();
        }
        request.getSession().setAttribute("msg", msg);
        return "usuarios.jsp";
    }
}
