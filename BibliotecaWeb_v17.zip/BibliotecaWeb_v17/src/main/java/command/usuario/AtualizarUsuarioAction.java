package command.usuario;

import command.ICommand;
import dao.usuario.AtualizarUsuarioDAO;
import dao.usuario.ConsultarUsuarioDAO;
import model.entidade.Usuario;
import model.enums.TipoUsuario;
import util.HashUtil;
import javax.servlet.http.HttpServletRequest;

public class AtualizarUsuarioAction implements ICommand {

    private final AtualizarUsuarioDAO dao;
    private final ConsultarUsuarioDAO consultarDAO;
    private final HttpServletRequest request;

    public AtualizarUsuarioAction(HttpServletRequest request) {
        this.request = request;
        this.dao = new AtualizarUsuarioDAO();
        this.consultarDAO = new ConsultarUsuarioDAO();
    }

    @Override
    public String executar() throws Exception {
        String msg;
        try {
            int id = Integer.parseInt(request.getParameter("txtid"));
            String senhaDigitada = request.getParameter("txtsenha");
            String senhaFinal;
            if (senhaDigitada != null && !senhaDigitada.trim().isEmpty()) {
                senhaFinal = HashUtil.sha256(senhaDigitada.trim());
            } else {
                senhaFinal = consultarDAO.consultarPorId(id).getSenha();
            }
            Usuario usuario = new Usuario(id,
                    request.getParameter("txtnome"),
                    request.getParameter("txtemail"),
                    senhaFinal,
                    TipoUsuario.valueOf(request.getParameter("seltipo")),
                    Boolean.parseBoolean(request.getParameter("chkativo"))
            );
            dao.executar(usuario);
            msg = "Usuário atualizado com sucesso.";
        } catch (Exception ex) {
            msg = "Erro ao atualizar: " + ex.getMessage();
        }
        request.getSession().setAttribute("msg", msg);
        return "usuarios.jsp";
    }
}
