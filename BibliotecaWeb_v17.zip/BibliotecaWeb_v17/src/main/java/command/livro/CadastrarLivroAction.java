package command.livro;

import command.ICommand;
import dao.livro.CadastrarLivroDAO;
import model.entidade.Livro;
import model.enums.StatusLivro;
import javax.servlet.http.HttpServletRequest;

public class CadastrarLivroAction implements ICommand {

    private final CadastrarLivroDAO dao;
    private final HttpServletRequest request;

    public CadastrarLivroAction(HttpServletRequest request) {
        this.request = request;
        this.dao = new CadastrarLivroDAO();
    }

    @Override
    public String executar() throws Exception {
        String msg;
        String titulo = request.getParameter("txttitulo");
        String autor = request.getParameter("txtautor");

        if (titulo == null || titulo.trim().isEmpty()) {
            msg = "Erro: preencha o campo Título.";
        } else if (autor == null || autor.trim().isEmpty()) {
            msg = "Erro: preencha o campo Autor.";
        } else {
            try {
                int ano = Integer.parseInt(request.getParameter("txtano").trim());
                int paginas = Integer.parseInt(request.getParameter("txtpaginas").trim());
                double preco = Double.parseDouble(request.getParameter("txtpreco").trim().replace(",", "."));
                int qtd = Integer.parseInt(request.getParameter("txtquantidade").trim());

                if (ano <= 0) {
                    msg = "Erro: Ano de publicação deve ser maior que zero.";
                } else if (paginas <= 0) {
                    msg = "Erro: Número de páginas deve ser maior que zero.";
                } else if (preco < 0) {
                    msg = "Erro: Preço não pode ser negativo.";
                } else if (qtd <= 0) {
                    msg = "Erro: Quantidade deve ser maior que zero.";
                } else {
                    Livro livro = new Livro.LivroBuilder()
                            .comTitulo(titulo.trim())
                            .comAutor(autor.trim())
                            .comEditora(request.getParameter("txteditora"))
                            .comIsbn(request.getParameter("txtisbn"))
                            .comGenero(request.getParameter("txtgenero"))
                            .comAnoPublicacao(ano)
                            .comNumeroPaginas(paginas)
                            .comIdioma(request.getParameter("txtidioma"))
                            .comPreco(preco)
                            .comQuantidade(qtd)
                            .comStatus(StatusLivro.valueOf(request.getParameter("selstatus")))
                            .build();
                    dao.executar(livro);
                    msg = "Livro cadastrado com sucesso.";
                }
            } catch (NumberFormatException ex) {
                msg = "Erro: Ano, Páginas, Preço e Quantidade devem ser números válidos.";
            }
        }
        request.getSession().setAttribute("msg", msg);
        return "livros.jsp";
    }
}
