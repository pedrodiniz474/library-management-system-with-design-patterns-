package command.livro;

import command.ICommand;
import dao.livro.DeletarLivroDAO;
import model.entidade.Livro;
import javax.servlet.http.HttpServletRequest;

public class DeletarLivroAction implements ICommand {

    private final DeletarLivroDAO dao;
    private final HttpServletRequest request;

    public DeletarLivroAction(HttpServletRequest request) {
        this.request = request;
        this.dao = new DeletarLivroDAO();
    }

    @Override
    public String executar() throws Exception {
        String msg;
        try {
            Livro livro = new Livro.LivroBuilder()
                    .comId(Integer.parseInt(request.getParameter("txtid").trim()))
                    .build();
            dao.executar(livro);
            msg = "Livro excluído com sucesso.";
        } catch (Exception ex) {
            msg = "Erro ao excluir: " + ex.getMessage();
        }
        request.getSession().setAttribute("msg", msg);
        return "livros.jsp";
    }
}
