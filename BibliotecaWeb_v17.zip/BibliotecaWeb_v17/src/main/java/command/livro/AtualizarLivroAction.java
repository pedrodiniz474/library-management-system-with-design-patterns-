package command.livro;

import command.ICommand;
import dao.livro.AtualizarLivroDAO;
import model.entidade.Livro;
import model.enums.StatusLivro;
import javax.servlet.http.HttpServletRequest;

public class AtualizarLivroAction implements ICommand {

    private final AtualizarLivroDAO dao;
    private final HttpServletRequest request;

    public AtualizarLivroAction(HttpServletRequest request) {
        this.request = request;
        this.dao = new AtualizarLivroDAO();
    }

    @Override
    public String executar() throws Exception {
        String msg;
        try {
            int ano = Integer.parseInt(request.getParameter("txtano").trim());
            int paginas = Integer.parseInt(request.getParameter("txtpaginas").trim());
            double preco = Double.parseDouble(request.getParameter("txtpreco").trim().replace(",", "."));
            int qtd = Integer.parseInt(request.getParameter("txtquantidade").trim());

            if (ano <= 0) {
                msg = "Erro: Ano de publicação deve ser maior que zero.";
            } else if (paginas <= 0) {
                msg = "Erro: Número de páginas deve ser maior que zero.";
            } else if (preco < 0) {
                msg = "Erro: Preço não pode ser negativo.";
            } else if (qtd <= 0) {
                msg = "Erro: Quantidade deve ser maior que zero.";
            } else {
                Livro livro = new Livro.LivroBuilder()
                        .comId(Integer.parseInt(request.getParameter("txtid").trim()))
                        .comTitulo(request.getParameter("txttitulo").trim())
                        .comAutor(request.getParameter("txtautor").trim())
                        .comEditora(request.getParameter("txteditora"))
                        .comIsbn(request.getParameter("txtisbn"))
                        .comGenero(request.getParameter("txtgenero"))
                        .comAnoPublicacao(ano)
                        .comNumeroPaginas(paginas)
                        .comIdioma(request.getParameter("txtidioma"))
                        .comPreco(preco)
                        .comQuantidade(qtd)
                        .comStatus(StatusLivro.valueOf(request.getParameter("selstatus")))
                        .build();
                dao.executar(livro);
                msg = "Livro atualizado com sucesso.";
            }
        } catch (NumberFormatException ex) {
            msg = "Erro: Ano, Páginas, Preço e Quantidade devem ser números válidos.";
        }
        request.getSession().setAttribute("msg", msg);
        return "livros.jsp";
    }
}
