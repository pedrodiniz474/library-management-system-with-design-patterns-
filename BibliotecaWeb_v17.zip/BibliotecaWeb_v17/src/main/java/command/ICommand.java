package command;

public interface ICommand {
    String executar() throws Exception;
}
