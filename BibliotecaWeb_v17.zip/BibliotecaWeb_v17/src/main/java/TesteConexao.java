/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author DINIZ
 */
import java.sql.Connection;
import util.ConnectionFactory;

public class TesteConexao {
    public static void main(String[] args) {
        try {
            Connection conn = ConnectionFactory.getConnection();

            if (conn != null) {
                System.out.println("✅ Conectado com sucesso ao banco!");
                conn.close();
            } else {
                System.out.println("❌ Falha na conexão.");
            }

        } catch (Exception e) {
            System.out.println("❌ Erro: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
