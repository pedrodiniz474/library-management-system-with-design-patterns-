/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.enums;

/**
 *
 * @author DINIZ
 */
public enum StatusLivro {
    DISPONIVEL,
    EMPRESTADO,
    INATIVO   
}
