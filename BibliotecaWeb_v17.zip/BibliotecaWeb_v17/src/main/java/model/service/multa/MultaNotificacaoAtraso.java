package model.service.multa;

import model.entidade.Emprestimo;

public class MultaNotificacaoAtraso extends MultaDecorator {

    public MultaNotificacaoAtraso(ICalculoMulta multaDecorada) {
        super(multaDecorada);
    }

    @Override
    public double calcular(Emprestimo emprestimo) {
        double valor = multaDecorada.calcular(emprestimo);
        if (valor > 0) {
            System.out.println("[NOTIFICACAO] Emprestimo " + emprestimo.getId()
                    + " com atraso de " + emprestimo.calcularDiasAtraso()
                    + " dia(s). Multa: R$ " + String.format("%.2f", valor));
        }
        return valor;
    }

    @Override
    public String getDescricao() {
        return multaDecorada.getDescricao() + " + Notificação de atraso";
    }
}
