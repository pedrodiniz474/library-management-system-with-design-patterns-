package model.service.multa;

import model.entidade.Emprestimo;

public class MultaDecorator implements ICalculoMulta {

    protected ICalculoMulta multaDecorada;

    public MultaDecorator(ICalculoMulta multaDecorada) {
        this.multaDecorada = multaDecorada;
    }

    @Override
    public double calcular(Emprestimo emprestimo) {
        return multaDecorada.calcular(emprestimo);
    }

    @Override
    public String getDescricao() {
        return multaDecorada.getDescricao();
    }
}
