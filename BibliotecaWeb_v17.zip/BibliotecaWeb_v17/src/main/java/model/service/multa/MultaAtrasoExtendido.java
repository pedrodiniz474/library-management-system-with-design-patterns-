package model.service.multa;

import model.entidade.Emprestimo;

public class MultaAtrasoExtendido extends MultaDecorator {

    private static final double PENALIDADE_FIXA = 10.0;
    private static final int LIMITE_DIAS = 7;

    public MultaAtrasoExtendido(ICalculoMulta multaDecorada) {
        super(multaDecorada);
    }

    @Override
    public double calcular(Emprestimo emprestimo) {
        return multaDecorada.calcular(emprestimo) + PENALIDADE_FIXA;
    }

    @Override
    public String getDescricao() {
        return multaDecorada.getDescricao()
                + " + Penalidade por atraso estendido (acima de "
                + LIMITE_DIAS + " dias, R$ " + PENALIDADE_FIXA + ",00 fixo)";
    }
}
