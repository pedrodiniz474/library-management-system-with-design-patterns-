package model.service.multa;

import model.entidade.Emprestimo;

public interface ICalculoMulta {
    double calcular(Emprestimo emprestimo);
    String getDescricao();
}
