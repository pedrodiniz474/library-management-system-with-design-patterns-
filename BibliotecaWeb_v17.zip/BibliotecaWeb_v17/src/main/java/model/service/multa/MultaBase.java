package model.service.multa;

import model.entidade.Emprestimo;

public class MultaBase implements ICalculoMulta {

    private static final double VALOR_POR_DIA = 2.0;

    @Override
    public double calcular(Emprestimo emprestimo) {
        int dias = emprestimo.calcularDiasAtraso();
        if (dias <= 0) {
            return 0.0;
        }
        return dias * VALOR_POR_DIA;
    }

    @Override
    public String getDescricao() {
        return "Multa base (R$ 2,00/dia)";
    }
}
