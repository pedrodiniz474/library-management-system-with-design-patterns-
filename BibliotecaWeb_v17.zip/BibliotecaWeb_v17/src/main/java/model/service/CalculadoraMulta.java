/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.service;

/**
 *
 * @author DINIZ
 */
public class CalculadoraMulta {
    
    private static final double VALOR_POR_DIA = 2.0;
    
    public static double calcular(int diasAtraso) {
        if (diasAtraso<= 0) {
            return 0.0;
        }
        return diasAtraso* VALOR_POR_DIA;
    }
    
}
