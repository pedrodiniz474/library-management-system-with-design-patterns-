package model.entidade;

public class EstanteAventura extends Estante {

    @Override
    public String getGenero() {
        return "Aventura";
    }
}
