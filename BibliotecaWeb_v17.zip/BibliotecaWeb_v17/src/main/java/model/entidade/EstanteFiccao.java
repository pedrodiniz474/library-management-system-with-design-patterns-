package model.entidade;

public class EstanteFiccao extends Estante {

    @Override
    public String getGenero() {
        return "Ficcao";
    }
}
