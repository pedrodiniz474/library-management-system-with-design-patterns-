package model.entidade;

public class EstanteRomance extends Estante {

    @Override
    public String getGenero() {
        return "Romance";
    }
}
