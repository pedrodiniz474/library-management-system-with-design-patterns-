package model.entidade;

public class EstanteTerror extends Estante {

    @Override
    public String getGenero() {
        return "Terror";
    }
}
