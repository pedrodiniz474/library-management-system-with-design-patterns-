package model.entidade;

import java.util.ArrayList;
import java.util.List;

public abstract class Estante {

    private int id;
    protected List<Livro> livros = new ArrayList<>();

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private String normalizarParaComparacao(String genero) {
        if (genero == null) return "";
        return genero.replaceAll("[^A-Za-z]", "").toLowerCase();
    }

    public void adicionarLivro(Livro livro) {
        String generoLivro = normalizarParaComparacao(livro.getGenero());
        String generoEstante = normalizarParaComparacao(getGenero());
        if (generoLivro.startsWith(generoEstante) || generoEstante.startsWith(generoLivro)) {
            livros.add(livro);
        }
    }

    public List<Livro> getLivros() {
        return livros;
    }

    public abstract String getGenero();
}
