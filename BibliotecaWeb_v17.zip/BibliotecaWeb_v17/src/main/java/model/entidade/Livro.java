/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.entidade;
import model.enums.StatusLivro;



/**
 *
 * @author DINIZ
 */
public class Livro {
    
    private int id;
    private String titulo;
    private String autor;
    private String editora;
    private String isbn;
    private String genero;
    private int anoPublicacao;
    private int numeroPaginas;
    private String idioma;
    private double preco;
    private int quantidade;
    private StatusLivro status;
    
    private Livro(LivroBuilder builder){
        this.id = builder.id;
        this.titulo = builder.titulo;
        this.autor= builder.autor;
        this.editora= builder.editora;
        this.isbn=builder.isbn;
        this.genero= builder.genero;
        this.anoPublicacao=builder.anoPublicacao;
        this.numeroPaginas = builder.numeroPaginas;
        this.idioma=builder.idioma;
        this.preco=builder.preco;
        this.quantidade= builder.quantidade;
        this.status= builder.status;    
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public String getEditora() {
        return editora;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getGenero() {
        return genero;
    }

    public int getAnoPublicacao() {
        return anoPublicacao;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public String getIdioma() {
        return idioma;
    }

    public double getPreco() {
        return preco;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public StatusLivro getStatus() {
        return status;
    }
    
    public static class LivroBuilder {
        
        private int id;
        private String titulo;
        private String autor;
        private String editora;
        private String isbn;
        private String genero;
        private int anoPublicacao;
        private int numeroPaginas;
        private String idioma;
        private double preco;
        private int quantidade;
        private StatusLivro status;
        
        public LivroBuilder comId(int id) {
            this.id = id;
            return this;
        }

        public LivroBuilder comTitulo(String titulo) {
            this.titulo = titulo;
            return this;
        }

        public LivroBuilder comAutor(String autor) {
            this.autor = autor;
            return this;
        }

        public LivroBuilder comEditora(String editora) {
            this.editora = editora;
            return this;
        }

        public LivroBuilder comIsbn(String isbn) {
            this.isbn = isbn;
            return this;
        }

        public LivroBuilder comGenero(String genero) {
            this.genero = genero;
            return this;
        }

        public LivroBuilder comAnoPublicacao(int anoPublicacao) {
            this.anoPublicacao = anoPublicacao;
            return this;
        }

        public LivroBuilder comNumeroPaginas(int numeroPaginas) {
            this.numeroPaginas = numeroPaginas;
            return this;
        }

        public LivroBuilder comIdioma(String idioma) {
            this.idioma = idioma;
            return this;
        }

        public LivroBuilder comPreco(double preco) {
            this.preco = preco;
            return this;
        }

        public LivroBuilder comQuantidade(int quantidade) {
            this.quantidade = quantidade;
            return this;
        }

        public LivroBuilder comStatus(StatusLivro status) {
            this.status = status;
            return this;
        }

        public Livro build() {
            return new Livro(this);
        }
  
    }
    
}
