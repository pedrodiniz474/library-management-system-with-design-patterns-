package model.entidade;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import model.service.multa.ICalculoMulta;
import model.service.multa.MultaBase;

public class Emprestimo {

    private int id;
    private Usuario usuario;
    private Livro livro;
    private LocalDate dataEmprestimo;
    private LocalDate dataPrevistaDevolucao;
    private LocalDate dataDevolucao;

    // Calculadora padrão injetada via ICalculoMulta — pode ser substituída por qualquer Decorator
    private ICalculoMulta calculadora = new MultaBase();

    private Emprestimo(EmprestimoBuilder builder) {
        this.id = builder.id;
        this.livro = builder.livro;
        this.usuario = builder.usuario;
        this.dataEmprestimo = builder.dataEmprestimo;
        this.dataPrevistaDevolucao = builder.dataPrevistaDevolucao;
        this.dataDevolucao = builder.dataDevolucao;
    }

    public int getId() {
        return id;
    }

    public Livro getLivro() {
        return livro;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public LocalDate getDataEmprestimo() {
        return dataEmprestimo;
    }

    public LocalDate getDataPrevistaDevolucao() {
        return dataPrevistaDevolucao;
    }

    public LocalDate getDataDevolucao() {
        return dataDevolucao;
    }

    // Responsabilidade da entidade: saber quantos dias de atraso ela tem.
    public int calcularDiasAtraso() {
        LocalDate dataFinal = (dataDevolucao != null) ? dataDevolucao : LocalDate.now();
        if (dataFinal.isAfter(dataPrevistaDevolucao)) {
            return (int) ChronoUnit.DAYS.between(dataPrevistaDevolucao, dataFinal);
        }
        return 0;
    }

    // O cálculo do valor delega ao ICalculoMulta (padrão Decorator).
    // Permite substituir a calculadora sem alterar a entidade — respeita OCP.
    public double calcularMulta() {
        return calculadora.calcular(this);
    }

    public static class EmprestimoBuilder {

        private int id;
        private Usuario usuario;
        private Livro livro;
        private LocalDate dataEmprestimo;
        private LocalDate dataPrevistaDevolucao;
        private LocalDate dataDevolucao;

        public EmprestimoBuilder comId(int id) {
            this.id = id;
            return this;
        }

        public EmprestimoBuilder comLivro(Livro livro) {
            this.livro = livro;
            return this;
        }

        public EmprestimoBuilder comUsuario(Usuario usuario) {
            this.usuario = usuario;
            return this;
        }

        public EmprestimoBuilder comDataEmprestimo(LocalDate d) {
            this.dataEmprestimo = d;
            return this;
        }

        public EmprestimoBuilder comDataPrevistaDevolucao(LocalDate d) {
            this.dataPrevistaDevolucao = d;
            return this;
        }

        public EmprestimoBuilder comDataDevolucao(LocalDate d) {
            this.dataDevolucao = d;
            return this;
        }

        public Emprestimo build() {
            return new Emprestimo(this);
        }
    }
}
