package controller;

import dao.usuario.ConsultarUsuarioDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.entidade.Usuario;
import util.HashUtil;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String email = request.getParameter("txtemail");
        String senha = request.getParameter("txtsenha");

        try {
            String senhaHash = (senha != null) ? HashUtil.sha256(senha.trim()) : "";
            Usuario usuario = new ConsultarUsuarioDAO().consultarPorEmailSenha(email, senhaHash);

            if (usuario != null && usuario.isAtivo()) {
                HttpSession session = request.getSession();
                session.setAttribute("usuarioLogado", usuario);

                if (usuario.getTipo().name().equals("ADMIN")) {
                    response.sendRedirect("dashboard.jsp");
                } else {
                    response.sendRedirect("home.jsp");
                }
            } else {
                request.setAttribute("erro", "Email ou senha inválidos.");
                request.getRequestDispatcher("index.jsp").forward(request, response);
            }
        } catch (Exception ex) {
            request.setAttribute("erro", "Erro ao conectar: " + ex.getMessage());
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
