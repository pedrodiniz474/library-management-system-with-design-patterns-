package controller;

import command.CommandFactory;
import command.ICommand;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.entidade.Usuario;

@WebServlet(name = "ManterServlet", urlPatterns = {"/ManterServlet"})
public class ManterServlet extends HttpServlet {

    private final Map<String, String[]> configuracoes;

    public ManterServlet() {
        configuracoes = new HashMap<>();

        configuracoes.put("livro", new String[]{"command.livro.", "LivroAction"});
        configuracoes.put("usuario", new String[]{"command.usuario.", "UsuarioAction"});
        configuracoes.put("emprestimo", new String[]{"command.emprestimo.", "EmprestimoAction"});
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogado") == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        String entidade = request.getParameter("entidade");
        String acao = request.getParameter("btnop");

        String[] config = configuracoes.get(entidade);
        if (config == null) {
            session.setAttribute("msg", "Entidade desconhecida: " + entidade);
            response.sendRedirect("index.jsp");
            return;
        }

        String packagePath = config[0];
        String sufixoAction = config[1];

        try {
            CommandFactory factory = new CommandFactory(packagePath, sufixoAction, request);
            ICommand command = factory.getCommand(acao);

            if (command == null) {
                session.setAttribute("msg", "Ação não encontrada: " + acao);
                response.sendRedirect(entidade + "s.jsp");
                return;
            }

            String pagina = command.executar();
            if (pagina != null) {
                request.getRequestDispatcher(pagina).forward(request, response);
            }
        } catch (Exception e) {
            boolean isAdmin = ((Usuario) session.getAttribute("usuarioLogado"))
                    .getTipo().name().equals("ADMIN");
            session.setAttribute("msg", "Erro inesperado: " + e.getMessage());
            response.sendRedirect(isAdmin ? entidade + "s.jsp" : "home.jsp");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet único - BiblioTech";
    }
}
