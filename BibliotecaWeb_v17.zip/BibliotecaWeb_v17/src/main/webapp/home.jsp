<%-- 
    Document   : home
    Created on : 12 de abr. de 2026, 22:09:22
    Author     : DINIZ
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="model.entidade.Usuario,model.entidade.Livro,model.entidade.Emprestimo,model.entidade.Estante,dao.livro.ConsultarLivroDAO,dao.emprestimo.ConsultarEmprestimoDAO,dao.estante.ConsultarEstanteDAO,model.service.multa.ICalculoMulta,model.service.multa.MultaBase,model.service.multa.MultaAtrasoExtendido,java.util.List,java.util.ArrayList"%>
<%
    Usuario logado = (Usuario) session.getAttribute("usuarioLogado");
    if (logado == null) {
        response.sendRedirect("index.jsp");
        return;
    }
    List<Livro> todos = new ConsultarLivroDAO().consultarTodos();
    List<Livro> disponiveis = new ArrayList<>();
    for (Livro l : todos) {
        if (l.getQuantidade() > 0 && !l.getStatus().name().equals("INATIVO")) {
            disponiveis.add(l);
        }
    }
    List<Emprestimo> todosEmp = new ConsultarEmprestimoDAO().consultarTodos();
    List<Emprestimo> meus = new ArrayList<>();
    for (Emprestimo e : todosEmp)
        if (e.getUsuario().getId() == logado.getId())
            meus.add(e);
    List<Estante> estantes = new ConsultarEstanteDAO().consultarTodas();
    // Verificar se usuário tem multa pendente (empréstimo não devolvido com atraso)
    boolean temMultaPendente = false;
    for (Emprestimo e : meus) {
        if (e.getDataDevolucao() == null && e.calcularDiasAtraso() > 0) {
            temMultaPendente = true;
            break;
        }
    }
%>
<!DOCTYPE html>
<html>
    <head>
        <title>BiblioTech</title>
        <meta charset="UTF-8">
        <style>
            body {
                font-family: Georgia, serif;
                background: #f5f0e8;
                margin: 0;
            }
            header {
                background: #2c2c2c;
                color: white;
                padding: 14px 28px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            header a {
                color: #aaa;
                font-size: 13px;
                text-decoration: none;
            }
            header a:hover {
                color: white;
            }
            .conteudo {
                padding: 24px 28px;
            }
            .saudacao {
                font-size: 14px;
                color: #666;
                margin-bottom: 20px;
            }
            h2 {
                font-size: 16px;
                margin: 24px 0 12px;
            }
            input[type=text] {
                padding: 7px 10px;
                border: 1px solid #ccc;
                font-family: Georgia, serif;
                font-size: 13px;
                margin-bottom: 12px;
                outline: none;
                width: 240px;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                background: white;
                margin-bottom: 32px;
            }
            th {
                background: #2c2c2c;
                color: white;
                padding: 10px 12px;
                text-align: left;
                font-size: 13px;
            }
            td {
                padding: 9px 12px;
                border-bottom: 1px solid #eee;
                font-size: 13px;
            }
            tr:hover td {
                background: #fdf8f2;
            }
            .btn-sm {
                padding: 3px 10px;
                font-size: 12px;
                border: none;
                cursor: pointer;
                font-family: Georgia, serif;
            }
            .btn-emprestar {
                background: #8b5e3c;
                color: white;
            }
            .btn-devolver {
                background: #1e8449;
                color: white;
            }
            .atrasado {
                color: #c0392b;
                font-weight: bold;
            }
            .pendente {
                color: #e67e22;
            }
            .overlay {
                display: none;
                position: fixed;
                inset: 0;
                background: rgba(0,0,0,0.4);
                justify-content: center;
                align-items: center;
                z-index: 99;
            }
            .overlay.ativo {
                display: flex;
            }
            .modal {
                background: white;
                padding: 28px;
                width: 340px;
                border: 1px solid #ddd;
            }
            .modal h3 {
                margin-bottom: 16px;
                font-size: 15px;
            }
            .campo {
                margin-bottom: 12px;
            }
            .campo label {
                display: block;
                font-size: 12px;
                color: #666;
                margin-bottom: 3px;
            }
            .campo input {
                width: 100%;
                padding: 7px 9px;
                border: 1px solid #ccc;
                font-family: Georgia, serif;
                font-size: 13px;
                box-sizing: border-box;
            }
            .modal-btns {
                display: flex;
                gap: 8px;
                margin-top: 16px;
            }
            .btn {
                padding: 7px 14px;
                border: none;
                cursor: pointer;
                font-family: Georgia, serif;
                font-size: 13px;
            }
            .btn-marrom {
                background: #8b5e3c;
                color: white;
            }
            .btn-escuro {
                background: #2c2c2c;
                color: white;
            }
            .msg {
                padding: 9px 12px;
                margin-bottom: 14px;
                font-size: 13px;
            }
            .sucesso {
                background: #eafaf1;
                color: #1e8449;
                border-left: 3px solid #1e8449;
            }
            .erro {
                background: #fdedec;
                color: #c0392b;
                border-left: 3px solid #c0392b;
            }
        .estante { background: white; border: 1px solid #ddd; margin-bottom: 12px; }
        .estante-header { background: #2c2c2c; color: white; padding: 11px 16px; cursor: pointer; display: flex; justify-content: space-between; font-size: 14px; }
        .estante-corpo { display: none; }
        .estante-corpo.aberto { display: block; }
        .vazio { padding: 14px 16px; font-size: 13px; color: #999; font-style: italic; }
        </style>
    </head>
    <body>
        <header>
            <span>BiblioTech</span>
            <div>
                <a href="estantes.jsp" style="color:#aaa;font-size:13px;text-decoration:none;margin-right:16px;">📚 Estantes</a>
                <a href="LogoutServlet">Sair</a>
            </div>
        </header>
        <div class="conteudo">
            <p class="saudacao">Olá, <strong><%= logado.getNome()%></strong></p>
            <% String msg = (String) session.getAttribute("msg"); session.removeAttribute("msg");
            if (msg != null) {%>
            <div class="msg <%= (msg.contains("Erro") || msg.contains("Bloqueado")) ? "erro" : "sucesso"%>"><%= msg%></div>
            <% } %>

            <% if (temMultaPendente) { %>
            <div class="msg erro" style="margin-bottom:16px;">
                &#9888; <strong>Atenção:</strong> Você possui livro(s) com devolução em atraso e multa pendente.
                Devolva o(s) livro(s) abaixo para liberar novos empréstimos.
            </div>
            <% } %>

            <h2>Livros Disponíveis</h2>
            <div style="display:flex;gap:8px;margin-bottom:12px;">
                <input type="text" id="busca" placeholder="buscar por título..." onkeyup="filtrarTitulo()" style="width:200px;">
                <input type="text" id="buscaId" placeholder="buscar por ID..." style="width:120px;">
                <button onclick="filtrarId()" style="padding:7px 12px;background:#2c2c2c;color:white;border:none;cursor:pointer;font-family:Georgia,serif;font-size:13px;">Buscar ID</button>
                <button onclick="limparFiltro()" style="padding:7px 12px;background:#888;color:white;border:none;cursor:pointer;font-family:Georgia,serif;font-size:13px;">Limpar</button>
            </div>
            <table id="tabela">
                <tr><th>ID</th><th>Título</th><th>Autor</th><th>Gênero</th><th>Ação</th></tr>
                        <% for (Livro l : disponiveis) {%>
                <tr>
                    <td><%= l.getId()%></td>
                    <td><%= l.getTitulo()%></td>
                    <td><%= l.getAutor()%></td>
                    <td><%= l.getGenero()%></td>
                    <td><button class="btn-sm btn-emprestar" onclick="abrirEmprestimo(<%= l.getId()%>, '<%= l.getTitulo().replace("'", "\'")%>')">Realizar Empréstimo</button></td>
                </tr>
                <% } %>
            </table>

            <h2>Meus Empréstimos</h2>
            <table>
                <tr><th>Livro</th><th>Empréstimo</th><th>Prev. Devolução</th><th>Situação</th><th>Ação</th></tr>
                        <% for (Emprestimo e : meus) {%>
                <tr>
                    <td><%= e.getLivro().getTitulo()%></td>
                    <td><%= e.getDataEmprestimo()%></td>
                    <td><%= e.getDataPrevistaDevolucao()%></td>
                    <td>
                        <% if (e.getDataDevolucao() != null) {%>
                        Devolvido em <%= e.getDataDevolucao()%>
                        <% } else if (e.calcularDiasAtraso() > 0) {
                            ICalculoMulta calc = new MultaBase();
                            if (e.calcularDiasAtraso() > 7) { calc = new MultaAtrasoExtendido(calc); }
                            double totalMulta = calc.calcular(e);
                        %>
                        <span class="atrasado"><%= e.calcularDiasAtraso()%> dia(s) — R$ <%= String.format("%.2f", totalMulta)%></span>
                        <% } else { %>
                        <span class="pendente">em andamento</span>
                        <% } %>
                    </td>
                    <td>
                        <% if (e.getDataDevolucao() == null) {
                            ICalculoMulta calcBtn = new MultaBase();
                            if (e.calcularDiasAtraso() > 7) { calcBtn = new MultaAtrasoExtendido(calcBtn); }
                            String descricaoMulta = e.calcularDiasAtraso() > 7
                                ? "Multa base + Penalidade por atraso estendido (acima de 7 dias, R$ 10,00 fixo)"
                                : "Multa base (R$ 2,00/dia)";
                        %>
                        <button class="btn-sm btn-devolver" onclick="devolver(<%= e.getId() %>, <%= e.calcularDiasAtraso() %>, '<%= String.format("%.2f", calcBtn.calcular(e)) %>', '<%= descricaoMulta %>')">Devolver</button>
                        <% } %>
                    </td>
                </tr>
                <% }%>
            </table>
        </div>

        <div class="overlay" id="modal">
            <div class="modal">
                <h3 id="modalTitulo">Emprestar Livro</h3>
                <p style="font-size:13px;color:#555;margin-bottom:12px;">
                    O prazo para devolução é de <strong>15 dias</strong> a partir de hoje.<br>
                    Data limite: <strong id="dataLimite"></strong>
                </p>
                <form action="ManterServlet" method="POST">
                    <input type="hidden" name="btnop" value="Cadastrar"><input type="hidden" name="entidade" value="emprestimo">
                    <input type="hidden" name="txtidUsuario" value="<%= logado.getId()%>">
                    <input type="hidden" name="txtidLivro" id="fIdLivro">
                    <div class="modal-btns">
                        <button type="submit" class="btn btn-marrom">Confirmar Empréstimo</button>
                        <button type="button" class="btn btn-escuro" onclick="document.getElementById('modal').classList.remove('ativo')">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>



        <!-- Modal confirmação de multa -->
        <div class="overlay" id="modalMulta">
            <div class="modal">
                <h3>Devolução com Atraso</h3>
                <p id="multaTexto" style="font-size:13px;color:#c0392b;margin-bottom:16px;"></p>
                <p style="font-size:13px;color:#555;margin-bottom:16px;">Você já pagou a multa?</p>
                <div class="modal-btns">
                    <button class="btn btn-marrom" onclick="confirmarDevolucao()">Sim, paguei</button>
                    <button class="btn btn-escuro" onclick="document.getElementById('modalMulta').classList.remove('ativo')">Não, cancelar</button>
                </div>
            </div>
        </div>

        <!-- Form hidden para devolução via POST -->
        <form id="fDevolver" action="ManterServlet" method="POST" style="display:none">
            <input type="hidden" name="btnop" value="Devolver"><input type="hidden" name="entidade" value="emprestimo">
            <input type="hidden" name="txtid" id="fDevolverID">
        </form>

        <script>
            function abrirEmprestimo(id, titulo) {
                document.getElementById('modalTitulo').innerText = 'Emprestar: ' + titulo;
                document.getElementById('fIdLivro').value = id;
                // Calcular data limite (hoje + 15 dias)
                var limite = new Date();
                limite.setDate(limite.getDate() + 15);
                var dia = String(limite.getDate()).padStart(2,'0');
                var mes = String(limite.getMonth()+1).padStart(2,'0');
                var ano = limite.getFullYear();
                document.getElementById('dataLimite').innerText = dia + '/' + mes + '/' + ano;
                document.getElementById('modal').classList.add('ativo');
            }
            function devolver(id, diasAtraso, multa, descricao) {
                if (diasAtraso > 0) {
                    // Tem multa — abre modal de confirmação
                    document.getElementById('fDevolverID').value = id;
                    document.getElementById('multaTexto').innerText =
                        'Atraso de ' + diasAtraso + ' dia(s). ' + descricao + '. Total: R$ ' + multa;
                    document.getElementById('modalMulta').classList.add('ativo');
                } else {
                    // Sem multa — confirma direto
                    if (confirm('Confirmar devolução no prazo?')) {
                        document.getElementById('fDevolverID').value = id;
                        document.getElementById('fDevolver').submit();
                    }
                }
            }
            function confirmarDevolucao() {
                document.getElementById('modalMulta').classList.remove('ativo');
                document.getElementById('fDevolver').submit();
            }
            function filtrarTitulo() {
                var b = document.getElementById('busca').value.toLowerCase();
                document.getElementById('buscaId').value = '';
                document.querySelectorAll('#tabela tr:not(:first-child)').forEach(tr => {
                    tr.style.display = tr.cells[1].innerText.toLowerCase().includes(b) ? '' : 'none';
                });
            }
            function filtrarId() {
                var id = document.getElementById('buscaId').value.trim();
                document.getElementById('busca').value = '';
                document.querySelectorAll('#tabela tr:not(:first-child)').forEach(tr => {
                    tr.style.display = (id === '' || tr.cells[0].innerText === id) ? '' : 'none';
                });
            }
            function limparFiltro() {
                document.getElementById('busca').value = '';
                document.getElementById('buscaId').value = '';
                document.querySelectorAll('#tabela tr:not(:first-child)').forEach(tr => {
                    tr.style.display = '';
                });
            }
        </script>
    </body>
</html>