<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>BiblioTech</title>
    <meta charset="UTF-8">
    <style>
        body { font-family: Georgia, serif; background: #f5f0e8; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .box { background: white; padding: 36px; width: 320px; border: 1px solid #ddd; }
        h2 { margin-bottom: 4px; font-size: 20px; }
        .sub { font-size: 12px; color: #999; margin-bottom: 24px; }
        label { display: block; font-size: 12px; color: #666; margin-bottom: 4px; }
        input { width: 100%; padding: 9px; border: 1px solid #ccc; font-family: Georgia, serif; font-size: 13px; margin-bottom: 14px; box-sizing: border-box; outline: none; }
        input:focus { border-color: #8b5e3c; }
        button { width: 100%; padding: 10px; background: #8b5e3c; color: white; border: none; font-family: Georgia, serif; font-size: 13px; cursor: pointer; }
        button:hover { background: #744e31; }
        .erro { color: #c0392b; font-size: 12px; margin-top: 10px; text-align: center; }
        .sucesso { color: #1e8449; font-size: 12px; margin-top: 10px; text-align: center; }
        .rodape { text-align: center; margin-top: 14px; font-size: 12px; color: #888; }
        .rodape a { color: #8b5e3c; text-decoration: none; }
        .rodape a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="box">
        <h2>BiblioTech</h2>
        <p class="sub">Faça login para continuar</p>
        <form action="LoginServlet" method="POST">
            <label>Email</label>
            <input type="text" name="txtemail">
            <label>Senha</label>
            <input type="password" name="txtsenha">
            <button type="submit">Entrar</button>
        </form>
        <%
            String erro = (String) request.getAttribute("erro");
            String msgSucesso = (String) session.getAttribute("msg");
            session.removeAttribute("msg");
            if (erro != null) { %><p class="erro"><%= erro %></p><% }
            if (msgSucesso != null) { %><p class="sucesso"><%= msgSucesso %></p><% }
        %>
        <p class="rodape">Não tem conta? <a href="cadastro.jsp">Criar conta</a></p>
    </div>
</body>
</html>
