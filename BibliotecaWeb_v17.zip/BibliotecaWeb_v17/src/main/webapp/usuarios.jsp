<%-- 
    Document   : usuarios
    Created on : 12 de abr. de 2026, 22:08:05
    Author     : DINIZ
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="model.entidade.Usuario,dao.usuario.ConsultarUsuarioDAO,java.util.List"%>
<% Usuario logado = (Usuario) session.getAttribute("usuarioLogado");
    if (logado == null) {
        response.sendRedirect("index.jsp");
        return;
    }
    if (!logado.getTipo().name().equals("ADMIN")) {
        response.sendRedirect("home.jsp");
        return;
    }
    List<Usuario> lista = new ConsultarUsuarioDAO().consultarTodos(); %>
<!DOCTYPE html>
<html>
    <head>
        <title>BiblioTech - Usuários</title>
        <meta charset="UTF-8">
        <style>
            body {
                font-family: Georgia, serif;
                background: #f5f0e8;
                margin: 0;
            }
            header {
                background: #2c2c2c;
                color: white;
                padding: 14px 28px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            header a {
                color: #aaa;
                font-size: 13px;
                text-decoration: none;
                margin-left: 16px;
            }
            header a:hover {
                color: white;
            }
            .conteudo {
                padding: 24px 28px;
            }
            .topo {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 16px;
            }
            .topo h2 {
                font-size: 17px;
            }
            input[type=text] {
                padding: 7px 10px;
                border: 1px solid #ccc;
                font-family: Georgia, serif;
                font-size: 13px;
                outline: none;
            }
            .btn {
                padding: 7px 14px;
                border: none;
                cursor: pointer;
                font-family: Georgia, serif;
                font-size: 13px;
            }
            .btn-marrom {
                background: #8b5e3c;
                color: white;
            }
            .btn-escuro {
                background: #2c2c2c;
                color: white;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                background: white;
            }
            th {
                background: #2c2c2c;
                color: white;
                padding: 10px 12px;
                text-align: left;
                font-size: 13px;
            }
            td {
                padding: 9px 12px;
                border-bottom: 1px solid #eee;
                font-size: 13px;
            }
            tr:hover td {
                background: #fdf8f2;
            }
            .btn-sm {
                padding: 3px 9px;
                font-size: 12px;
                border: none;
                cursor: pointer;
                font-family: Georgia, serif;
                margin-right: 4px;
            }
            .btn-editar {
                background: #e8a838;
                color: white;
            }
            .btn-excluir {
                background: #c0392b;
                color: white;
            }
            .overlay {
                display: none;
                position: fixed;
                inset: 0;
                background: rgba(0,0,0,0.4);
                justify-content: center;
                align-items: center;
                z-index: 99;
            }
            .overlay.ativo {
                display: flex;
            }
            .modal {
                background: white;
                padding: 28px;
                width: 380px;
                border: 1px solid #ddd;
            }
            .modal h3 {
                margin-bottom: 16px;
                font-size: 15px;
            }
            .campo {
                margin-bottom: 12px;
            }
            .campo label {
                display: block;
                font-size: 12px;
                color: #666;
                margin-bottom: 3px;
            }
            .campo input, .campo select {
                width: 100%;
                padding: 7px 9px;
                border: 1px solid #ccc;
                font-family: Georgia, serif;
                font-size: 13px;
                box-sizing: border-box;
            }
            .modal-btns {
                display: flex;
                gap: 8px;
                margin-top: 16px;
            }
            .msg {
                padding: 9px 12px;
                margin-bottom: 14px;
                font-size: 13px;
            }
            .sucesso {
                background: #eafaf1;
                color: #1e8449;
                border-left: 3px solid #1e8449;
            }
            .erro {
                background: #fdedec;
                color: #c0392b;
                border-left: 3px solid #c0392b;
            }
        </style>
    </head>
    <body>
        <header>
            <span>BiblioTech</span>
            <div><a href="dashboard.jsp">← Dashboard</a><a href="LogoutServlet">Sair</a></div>
        </header>
        <div class="conteudo">
            <div class="topo">
                <h2>Usuários</h2>
                <div style="display:flex;gap:8px">
                    <input type="text" id="busca" placeholder="buscar por nome..." onkeyup="filtrar()">
                    <button class="btn btn-marrom" onclick="abrirNovo()">+ Novo</button>
                </div>
            </div>
            <% String msg = (String) session.getAttribute("msg"); session.removeAttribute("msg");
            if (msg != null) {%>
            <div class="msg <%= msg.contains("Erro") ? "erro" : "sucesso"%>"><%= msg%></div>
            <% } %>
            <table id="tabela">
                <tr><th>ID</th><th>Nome</th><th>Email</th><th>Tipo</th><th>Ativo</th><th>Ações</th></tr>
                        <% for (Usuario u : lista) {%>
                <tr>
                    <td><%= u.getId()%></td>
                    <td><%= u.getNome()%></td>
                    <td><%= u.getEmail()%></td>
                    <td><%= u.getTipo()%></td>
                    <td><%= u.isAtivo() ? "Sim" : "Não"%></td>
                    <td>
                        <button class="btn-sm btn-editar" onclick="abrirEditar(<%= u.getId()%>, '<%= u.getNome().replace("'", "\'")%>', '<%= u.getEmail().replace("'", "\'")%>', '<%= u.getTipo()%>',<%= u.isAtivo()%>)">Editar</button>
                        <button class="btn-sm btn-excluir" onclick="excluir(<%= u.getId()%>, '<%= u.getNome().replace("'", "\'")%>')">Excluir</button>
                    </td>
                </tr>
                <% }%>
            </table>
        </div>

        <div class="overlay" id="modal">
            <div class="modal">
                <h3 id="modalTitulo">Novo Usuário</h3>
                <form action="ManterServlet" method="POST">
                    <input type="hidden" name="txtid" id="fId">
                    <input type="hidden" name="btnop" id="fOp" value="Cadastrar"><input type="hidden" name="entidade" value="usuario">
                    <div class="campo"><label>Nome</label><input type="text" name="txtnome" id="fNome"></div>
                    <div class="campo"><label>Email</label><input type="text" name="txtemail" id="fEmail"></div>
                    <div class="campo"><label>Senha</label><input type="password" name="txtsenha" id="fSenha"></div>
                    <div class="campo"><label>Tipo</label>
                        <select name="seltipo" id="fTipo">
                            <option value="USER">Usuário</option>
                            <option value="ADMIN">Administrador</option>
                        </select>
                    </div>
                    <div class="campo"><label>Ativo</label>
                        <select name="chkativo" id="fAtivo">
                            <option value="true">Sim</option>
                            <option value="false">Não</option>
                        </select>
                    </div>
                    <div class="modal-btns">
                        <button type="submit" class="btn btn-marrom">Salvar</button>
                        <button type="button" class="btn btn-escuro" onclick="fechar()">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>

        <form id="fExcluir" action="ManterServlet" method="POST" style="display:none">
            <input type="hidden" name="txtid" id="fExcluirId">
            <input type="hidden" name="btnop" value="Deletar"><input type="hidden" name="entidade" value="usuario">
        </form>

        <script>
            function abrirNovo() {
                document.getElementById('modalTitulo').innerText = 'Novo Usuário';
                document.getElementById('fOp').value = 'Cadastrar';
                ['fId', 'fNome', 'fEmail', 'fSenha'].forEach(id => document.getElementById(id).value = '');
                document.getElementById('modal').classList.add('ativo');
            }
            function abrirEditar(id, nome, email, tipo, ativo) {
                document.getElementById('modalTitulo').innerText = 'Editar Usuário';
                document.getElementById('fOp').value = 'Atualizar';
                document.getElementById('fId').value = id;
                document.getElementById('fNome').value = nome;
                document.getElementById('fEmail').value = email;
                document.getElementById('fTipo').value = tipo;
                document.getElementById('fAtivo').value = ativo;
                document.getElementById('modal').classList.add('ativo');
            }
            function fechar() {
                document.getElementById('modal').classList.remove('ativo');
            }
            function excluir(id, nome) {
                if (confirm('Excluir "' + nome + '"?')) {
                    document.getElementById('fExcluirId').value = id;
                    document.getElementById('fExcluir').submit();
                }
            }
            function filtrar() {
                var b = document.getElementById('busca').value.toLowerCase();
                document.querySelectorAll('#tabela tr:not(:first-child)').forEach(tr => {
                    tr.style.display = tr.cells[1].innerText.toLowerCase().includes(b) ? '' : 'none';
                });
            }
        </script>
    </body>
</html>