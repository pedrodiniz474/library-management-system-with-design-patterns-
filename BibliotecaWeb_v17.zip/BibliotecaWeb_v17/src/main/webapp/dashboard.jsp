<%-- 
    Document   : dashboard
    Created on : 12 de abr. de 2026, 22:07:14
    Author     : DINIZ
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="model.entidade.Usuario"%>
<% Usuario logado = (Usuario) session.getAttribute("usuarioLogado");
    if (logado == null) {
        response.sendRedirect("index.jsp");
        return;
    }%>
<!DOCTYPE html>
<html>
    <head>
        <title>BiblioTech</title>
        <meta charset="UTF-8">
        <style>
            body {
                font-family: Georgia, serif;
                background: #f5f0e8;
                margin: 0;
            }
            header {
                background: #2c2c2c;
                color: white;
                padding: 14px 28px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            header a {
                color: #aaa;
                font-size: 13px;
                text-decoration: none;
            }
            header a:hover {
                color: white;
            }
            .conteudo {
                padding: 28px;
            }
            .saudacao {
                font-size: 14px;
                color: #666;
                margin-bottom: 24px;
            }
            .cards {
                display: flex;
                gap: 16px;
                flex-wrap: wrap;
            }
            .card {
                background: white;
                border: 1px solid #ddd;
                padding: 24px 28px;
                width: 180px;
                text-decoration: none;
                color: #2c2c2c;
            }
            .card:hover {
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
            .card .icone {
                font-size: 24px;
                margin-bottom: 8px;
            }
            .card .nome {
                font-size: 15px;
                font-weight: bold;
            }
        </style>
    </head>
    <body>
        <header>
            <span>BiblioTech</span>
            <a href="LogoutServlet">Sair</a>
        </header>
        <div class="conteudo">
            <p class="saudacao">Olá, <strong><%= logado.getNome()%></strong></p>
            <div class="cards">
                <a href="livros.jsp" class="card"><div class="icone">📚</div><div class="nome">Livros</div></a>
                <a href="usuarios.jsp" class="card"><div class="icone">👤</div><div class="nome">Usuários</div></a>
                <a href="emprestimos.jsp" class="card"><div class="icone">📋</div><div class="nome">Empréstimos</div></a>
                <a href="estantes.jsp" class="card"><div class="icone">🗄️</div><div class="nome">Estantes</div></a>
            </div>
        </div>
    </body>
</html>
