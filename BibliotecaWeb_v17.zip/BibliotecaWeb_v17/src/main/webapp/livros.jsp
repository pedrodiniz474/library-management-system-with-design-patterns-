<%-- 
    Document   : livros
    Created on : 12 de abr. de 2026, 22:07:39
    Author     : DINIZ
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="model.entidade.Usuario,model.entidade.Livro,dao.livro.ConsultarLivroDAO,java.util.List"%>
<% Usuario logado = (Usuario) session.getAttribute("usuarioLogado");
    if (logado == null) {
        response.sendRedirect("index.jsp");
        return;
    }
    List<Livro> lista = new ConsultarLivroDAO().consultarTodos(); %>
<!DOCTYPE html>
<html>
    <head>
        <title>BiblioTech - Livros</title>
        <meta charset="UTF-8">
        <style>
            body {
                font-family: Georgia, serif;
                background: #f5f0e8;
                margin: 0;
            }
            header {
                background: #2c2c2c;
                color: white;
                padding: 14px 28px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            header a {
                color: #aaa;
                font-size: 13px;
                text-decoration: none;
                margin-left: 16px;
            }
            header a:hover {
                color: white;
            }
            .conteudo {
                padding: 24px 28px;
            }
            .topo {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 16px;
            }
            .topo h2 {
                font-size: 17px;
            }
            .acoes-topo {
                display: flex;
                gap: 8px;
            }
            input[type=text] {
                padding: 7px 10px;
                border: 1px solid #ccc;
                font-family: Georgia, serif;
                font-size: 13px;
                outline: none;
            }
            input[type=text]:focus {
                border-color: #8b5e3c;
            }
            .btn {
                padding: 7px 14px;
                border: none;
                cursor: pointer;
                font-family: Georgia, serif;
                font-size: 13px;
            }
            .btn-marrom {
                background: #8b5e3c;
                color: white;
            }
            .btn-escuro {
                background: #2c2c2c;
                color: white;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                background: white;
            }
            th {
                background: #2c2c2c;
                color: white;
                padding: 10px 12px;
                text-align: left;
                font-size: 13px;
            }
            td {
                padding: 9px 12px;
                border-bottom: 1px solid #eee;
                font-size: 13px;
            }
            tr:hover td {
                background: #fdf8f2;
            }
            .btn-sm {
                padding: 3px 9px;
                font-size: 12px;
                border: none;
                cursor: pointer;
                font-family: Georgia, serif;
                margin-right: 4px;
            }
            .btn-editar {
                background: #e8a838;
                color: white;
            }
            .btn-excluir {
                background: #c0392b;
                color: white;
            }
            .overlay {
                display: none;
                position: fixed;
                inset: 0;
                background: rgba(0,0,0,0.4);
                justify-content: center;
                align-items: center;
                z-index: 99;
            }
            .overlay.ativo {
                display: flex;
            }
            .modal {
                background: white;
                padding: 28px;
                width: 440px;
                max-height: 88vh;
                overflow-y: auto;
                border: 1px solid #ddd;
            }
            .modal h3 {
                margin-bottom: 16px;
                font-size: 15px;
            }
            .campo {
                margin-bottom: 12px;
            }
            .campo label {
                display: block;
                font-size: 12px;
                color: #666;
                margin-bottom: 3px;
            }
            .campo input, .campo select {
                width: 100%;
                padding: 7px 9px;
                border: 1px solid #ccc;
                font-family: Georgia, serif;
                font-size: 13px;
                box-sizing: border-box;
            }
            .modal-btns {
                display: flex;
                gap: 8px;
                margin-top: 16px;
            }
            .msg {
                padding: 9px 12px;
                margin-bottom: 14px;
                font-size: 13px;
            }
            .sucesso {
                background: #eafaf1;
                color: #1e8449;
                border-left: 3px solid #1e8449;
            }
            .erro {
                background: #fdedec;
                color: #c0392b;
                border-left: 3px solid #c0392b;
            }
        </style>
    </head>
    <body>
        <header>
            <span>BiblioTech</span>
            <div><a href="dashboard.jsp">← Dashboard</a><a href="LogoutServlet">Sair</a></div>
        </header>
        <div class="conteudo">
            <div class="topo">
                <h2>Livros</h2>
                <div class="acoes-topo">
                    <input type="text" id="busca" placeholder="buscar por título..." onkeyup="filtrar()" style="width:180px;">
                    <input type="text" id="buscaId" placeholder="buscar por ID..." style="width:110px;">
                    <button class="btn btn-escuro" onclick="filtrarId()">Buscar ID</button>
                    <button class="btn btn-escuro" onclick="limparFiltro()">Limpar</button>
                    <button class="btn btn-marrom" onclick="abrirNovo()">+ Novo</button>
                </div>
            </div>
            <% String msg = (String) session.getAttribute("msg"); session.removeAttribute("msg");
            if (msg != null) {%>
            <div class="msg <%= msg.contains("Erro") ? "erro" : "sucesso"%>"><%= msg%></div>
            <% } %>
            <table id="tabela">
                <tr><th>ID</th><th>Título</th><th>Autor</th><th>Gênero</th><th>Qtd</th><th>Status</th><th>Ações</th></tr>
                        <% for (Livro l : lista) {%>
                <tr>
                    <td><%= l.getId()%></td>
                    <td><%= l.getTitulo()%></td>
                    <td><%= l.getAutor()%></td>
                    <td><%= l.getGenero()%></td>
                    <td><%= l.getQuantidade()%></td>
                    <td><%= l.getStatus()%></td>
                    <td>
                        <button class="btn-sm btn-editar" onclick="abrirEditar(<%= l.getId()%>, '<%= l.getTitulo().replace("'", "\'")%>', '<%= l.getAutor().replace("'", "\'")%>', '<%= l.getEditora().replace("'", "\'")%>', '<%= l.getIsbn()%>', '<%= l.getGenero()%>',<%= l.getAnoPublicacao()%>,<%= l.getNumeroPaginas()%>, '<%= l.getIdioma()%>',<%= l.getPreco()%>,<%= l.getQuantidade()%>, '<%= l.getStatus()%>')">Editar</button>
                        <button class="btn-sm btn-excluir" onclick="excluir(<%= l.getId()%>, '<%= l.getTitulo().replace("'", "\'")%>')">Excluir</button>
                    </td>
                </tr>
                <% }%>
            </table>
        </div>

        <div class="overlay" id="modal">
            <div class="modal">
                <h3 id="modalTitulo">Novo Livro</h3>
                <form action="ManterServlet" method="POST">
                    <input type="hidden" name="txtid" id="fId">
                    <input type="hidden" name="btnop" id="fOp" value="Cadastrar"><input type="hidden" name="entidade" value="livro">
                    <div class="campo"><label>Título</label><input type="text" name="txttitulo" id="fTitulo"></div>
                    <div class="campo"><label>Autor</label><input type="text" name="txtautor" id="fAutor"></div>
                    <div class="campo"><label>Editora</label><input type="text" name="txteditora" id="fEditora"></div>
                    <div class="campo"><label>ISBN</label><input type="text" name="txtisbn" id="fIsbn"></div>
                    <div class="campo"><label>Gênero</label>
                        <select name="txtgenero" id="fGenero">
                            <option value="Ficcao">Ficcao</option>
                            <option value="Romance">Romance</option>
                            <option value="Terror">Terror</option>
                            <option value="Aventura">Aventura</option>
                        </select>
                    </div>
                    <div class="campo"><label>Ano</label><input type="text" name="txtano" id="fAno"></div>
                    <div class="campo"><label>Páginas</label><input type="text" name="txtpaginas" id="fPaginas"></div>
                    <div class="campo"><label>Idioma</label><input type="text" name="txtidioma" id="fIdioma"></div>
                    <div class="campo"><label>Preço</label><input type="text" name="txtpreco" id="fPreco"></div>
                    <div class="campo"><label>Quantidade</label><input type="text" name="txtquantidade" id="fQtd"></div>
                    <div class="campo"><label>Status</label>
                        <select name="selstatus" id="fStatus">
                            <option value="DISPONIVEL">Disponível</option>
                            <option value="EMPRESTADO">Emprestado</option>
                            <option value="INATIVO">Inativo</option>
                        </select>
                    </div>
                    <div class="modal-btns">
                        <button type="submit" class="btn btn-marrom">Salvar</button>
                        <button type="button" class="btn btn-escuro" onclick="fechar()">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>

        <form id="fExcluir" action="ManterServlet" method="POST" style="display:none">
            <input type="hidden" name="txtid" id="fExcluirId">
            <input type="hidden" name="btnop" value="Deletar"><input type="hidden" name="entidade" value="livro">
        </form>

        <script>
            function abrirNovo() {
                document.getElementById('modalTitulo').innerText = 'Novo Livro';
                document.getElementById('fOp').value = 'Cadastrar';
                ['fId', 'fTitulo', 'fAutor', 'fEditora', 'fIsbn', 'fAno', 'fPaginas', 'fIdioma', 'fPreco', 'fQtd'].forEach(id => document.getElementById(id).value = '');
                document.getElementById('modal').classList.add('ativo');
            }
            function abrirEditar(id, titulo, autor, editora, isbn, genero, ano, paginas, idioma, preco, qtd, status) {
                document.getElementById('modalTitulo').innerText = 'Editar Livro';
                document.getElementById('fOp').value = 'Atualizar';
                document.getElementById('fId').value = id;
                document.getElementById('fTitulo').value = titulo;
                document.getElementById('fAutor').value = autor;
                document.getElementById('fEditora').value = editora;
                document.getElementById('fIsbn').value = isbn;
                document.getElementById('fGenero').value = genero;
                document.getElementById('fAno').value = ano;
                document.getElementById('fPaginas').value = paginas;
                document.getElementById('fIdioma').value = idioma;
                document.getElementById('fPreco').value = preco;
                document.getElementById('fQtd').value = qtd;
                document.getElementById('fStatus').value = status;
                document.getElementById('modal').classList.add('ativo');
            }
            function fechar() {
                document.getElementById('modal').classList.remove('ativo');
            }
            function excluir(id, titulo) {
                if (confirm('Excluir "' + titulo + '"?')) {
                    document.getElementById('fExcluirId').value = id;
                    document.getElementById('fExcluir').submit();
                }
            }
            function filtrar() {
                document.getElementById('buscaId').value = '';
                var b = document.getElementById('busca').value.toLowerCase();
                document.querySelectorAll('#tabela tr:not(:first-child)').forEach(tr => {
                    tr.style.display = tr.cells[1].innerText.toLowerCase().includes(b) ? '' : 'none';
                });
            }
            function filtrarId() {
                var id = document.getElementById('buscaId').value.trim();
                document.getElementById('busca').value = '';
                document.querySelectorAll('#tabela tr:not(:first-child)').forEach(tr => {
                    tr.style.display = (id === '' || tr.cells[0].innerText === id) ? '' : 'none';
                });
            }
            function limparFiltro() {
                document.getElementById('busca').value = '';
                document.getElementById('buscaId').value = '';
                document.querySelectorAll('#tabela tr:not(:first-child)').forEach(tr => {
                    tr.style.display = '';
                });
            }
        </script>
    </body>
</html>
