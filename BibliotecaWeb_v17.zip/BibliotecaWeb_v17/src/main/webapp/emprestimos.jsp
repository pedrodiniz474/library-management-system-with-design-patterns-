<%-- 
    Document   : emprestimos
    Created on : 12 de abr. de 2026, 22:08:32
    Author     : DINIZ
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="model.entidade.Usuario,model.entidade.Emprestimo,dao.emprestimo.ConsultarEmprestimoDAO,java.util.List"%>
<% Usuario logado = (Usuario) session.getAttribute("usuarioLogado");
    if (logado == null) {
        response.sendRedirect("index.jsp");
        return;
    }
    if (!logado.getTipo().name().equals("ADMIN")) {
        response.sendRedirect("home.jsp");
        return;
    }
    List<Emprestimo> lista = new ConsultarEmprestimoDAO().consultarTodos(); %>
<!DOCTYPE html>
<html>
    <head>
        <title>BiblioTech - Empréstimos</title>
        <meta charset="UTF-8">
        <style>
            body {
                font-family: Georgia, serif;
                background: #f5f0e8;
                margin: 0;
            }
            header {
                background: #2c2c2c;
                color: white;
                padding: 14px 28px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            header a {
                color: #aaa;
                font-size: 13px;
                text-decoration: none;
                margin-left: 16px;
            }
            header a:hover {
                color: white;
            }
            .conteudo {
                padding: 24px 28px;
            }
            .topo {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 16px;
            }
            .topo h2 {
                font-size: 17px;
            }
            .btn {
                padding: 7px 14px;
                border: none;
                cursor: pointer;
                font-family: Georgia, serif;
                font-size: 13px;
            }
            .btn-marrom {
                background: #8b5e3c;
                color: white;
            }
            .btn-escuro {
                background: #2c2c2c;
                color: white;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                background: white;
            }
            th {
                background: #2c2c2c;
                color: white;
                padding: 10px 12px;
                text-align: left;
                font-size: 13px;
            }
            td {
                padding: 9px 12px;
                border-bottom: 1px solid #eee;
                font-size: 13px;
            }
            tr:hover td {
                background: #fdf8f2;
            }
            .btn-sm {
                padding: 3px 9px;
                font-size: 12px;
                border: none;
                cursor: pointer;
                font-family: Georgia, serif;
                margin-right: 4px;
            }
            .btn-devolver {
                background: #1e8449;
                color: white;
            }
            .btn-excluir {
                background: #c0392b;
                color: white;
            }
            .atrasado {
                color: #c0392b;
                font-weight: bold;
            }
            .pendente {
                color: #e67e22;
            }
            .overlay {
                display: none;
                position: fixed;
                inset: 0;
                background: rgba(0,0,0,0.4);
                justify-content: center;
                align-items: center;
                z-index: 99;
            }
            .overlay.ativo {
                display: flex;
            }
            .modal {
                background: white;
                padding: 28px;
                width: 380px;
                border: 1px solid #ddd;
            }
            .modal h3 {
                margin-bottom: 16px;
                font-size: 15px;
            }
            .campo {
                margin-bottom: 12px;
            }
            .campo label {
                display: block;
                font-size: 12px;
                color: #666;
                margin-bottom: 3px;
            }
            .campo input {
                width: 100%;
                padding: 7px 9px;
                border: 1px solid #ccc;
                font-family: Georgia, serif;
                font-size: 13px;
                box-sizing: border-box;
            }
            .modal-btns {
                display: flex;
                gap: 8px;
                margin-top: 16px;
            }
            .msg {
                padding: 9px 12px;
                margin-bottom: 14px;
                font-size: 13px;
            }
            .sucesso {
                background: #eafaf1;
                color: #1e8449;
                border-left: 3px solid #1e8449;
            }
            .erro {
                background: #fdedec;
                color: #c0392b;
                border-left: 3px solid #c0392b;
            }
        </style>
    </head>
    <body>
        <header>
            <span>BiblioTech</span>
            <div><a href="dashboard.jsp">← Dashboard</a><a href="LogoutServlet">Sair</a></div>
        </header>
        <div class="conteudo">
            <div class="topo">
                <h2>Empréstimos</h2>
                <button class="btn btn-marrom" onclick="document.getElementById('modal').classList.add('ativo')">+ Novo</button>
            </div>
            <% String msg = (String) session.getAttribute("msg"); session.removeAttribute("msg");
            if (msg != null) {%>
            <div class="msg <%= msg.contains("Erro") ? "erro" : "sucesso"%>"><%= msg%></div>
            <% } %>
            <table>
                <tr><th>ID</th><th>Usuário</th><th>Livro</th><th>Empréstimo</th><th>Prev. Devolução</th><th>Situação</th><th>Multa</th><th>Ações</th></tr>
                        <% for (Emprestimo e : lista) {%>
                <tr>
                    <td><%= e.getId()%></td>
                    <td><%= e.getUsuario().getNome()%></td>
                    <td><%= e.getLivro().getTitulo()%></td>
                    <td><%= e.getDataEmprestimo()%></td>
                    <td><%= e.getDataPrevistaDevolucao()%></td>
                    <td>
                        <% if (e.getDataDevolucao() != null) {%>
                        Devolvido em <%= e.getDataDevolucao()%>
                        <% } else if (e.calcularDiasAtraso() > 0) {%>
                        <span class="atrasado"><%= e.calcularDiasAtraso()%> dia(s) de atraso</span>
                        <% } else { %>
                        <span class="pendente">pendente</span>
                        <% }%>
                    </td>
                    <td><%= e.calcularMulta() > 0 ? "R$ " + String.format("%.2f", e.calcularMulta()) : "—"%></td>
                    <td>
                        <% if (e.getDataDevolucao() == null) {%>
                        <button class="btn-sm btn-devolver" onclick="devolver(<%= e.getId()%>)">Devolver</button>
                        <% }%>
                        <button class="btn-sm btn-excluir" onclick="excluir(<%= e.getId()%>)">Excluir</button>
                    </td>
                </tr>
                <% }%>
            </table>
        </div>

        <div class="overlay" id="modal">
            <div class="modal">
                <h3>Novo Empréstimo</h3>
                <form action="ManterServlet" method="POST">
                    <input type="hidden" name="btnop" value="Cadastrar"><input type="hidden" name="entidade" value="emprestimo">
                    <div class="campo"><label>ID do Usuário</label><input type="text" name="txtidUsuario"></div>
                    <div class="campo"><label>ID do Livro</label><input type="text" name="txtidLivro"></div>
                    <div class="campo"><label>Data do Empréstimo</label><input type="date" name="txtdataEmprestimo"></div>
                    <div class="campo"><label>Data Prevista de Devolução</label><input type="date" name="txtdataPrevista"></div>
                    <div class="modal-btns">
                        <button type="submit" class="btn btn-marrom">Salvar</button>
                        <button type="button" class="btn btn-escuro" onclick="document.getElementById('modal').classList.remove('ativo')">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>

        <form id="fDevolver" action="ManterServlet" method="POST" style="display:none">
            <input type="hidden" name="txtid" id="fDevolverID">
            <input type="hidden" name="btnop" value="Devolver"><input type="hidden" name="entidade" value="emprestimo">
        </form>
        <form id="fExcluir" action="ManterServlet" method="POST" style="display:none">
            <input type="hidden" name="txtid" id="fExcluirId">
            <input type="hidden" name="btnop" value="Deletar"><input type="hidden" name="entidade" value="emprestimo">
        </form>

        <script>
            function devolver(id) {
                if (confirm('Registrar devolução do empréstimo #' + id + '?')) {
                    document.getElementById('fDevolverID').value = id;
                    document.getElementById('fDevolver').submit();
                }
            }
            function excluir(id) {
                if (confirm('Excluir empréstimo #' + id + '?')) {
                    document.getElementById('fExcluirId').value = id;
                    document.getElementById('fExcluir').submit();
                }
            }
        </script>
    </body>
</html>
