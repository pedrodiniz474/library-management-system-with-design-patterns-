<%-- 
    Document   : estantes
    Created on : 12 de abr. de 2026, 22:08:56
    Author     : DINIZ
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="model.entidade.Usuario,model.entidade.Estante,model.entidade.Livro,dao.estante.ConsultarEstanteDAO,java.util.List"%>
<% Usuario logado = (Usuario) session.getAttribute("usuarioLogado");
    if (logado == null) {
        response.sendRedirect("index.jsp");
        return;
    }
    List<Estante> estantes = new ConsultarEstanteDAO().consultarTodas(); %>
<!DOCTYPE html>
<html>
    <head>
        <title>BiblioTech - Estantes</title>
        <meta charset="UTF-8">
        <style>
            body {
                font-family: Georgia, serif;
                background: #f5f0e8;
                margin: 0;
            }
            header {
                background: #2c2c2c;
                color: white;
                padding: 14px 28px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            header a {
                color: #aaa;
                font-size: 13px;
                text-decoration: none;
                margin-left: 16px;
            }
            header a:hover {
                color: white;
            }
            .conteudo {
                padding: 24px 28px;
            }
            h2 {
                font-size: 17px;
                margin-bottom: 20px;
            }
            .estante {
                background: white;
                border: 1px solid #ddd;
                margin-bottom: 16px;
            }
            .estante-header {
                background: #2c2c2c;
                color: white;
                padding: 11px 16px;
                cursor: pointer;
                display: flex;
                justify-content: space-between;
                font-size: 14px;
            }
            .estante-corpo {
                display: none;
            }
            .estante-corpo.aberto {
                display: block;
            }
            table {
                width: 100%;
                border-collapse: collapse;
            }
            th {
                background: #f0ebe1;
                color: #555;
                padding: 9px 12px;
                text-align: left;
                font-size: 12px;
            }
            td {
                padding: 9px 12px;
                border-bottom: 1px solid #f0ebe1;
                font-size: 13px;
            }
            tr:hover td {
                background: #fdf8f2;
            }
            .vazio {
                padding: 14px 16px;
                font-size: 13px;
                color: #999;
                font-style: italic;
            }
        </style>
    </head>
    <body>
        <header>
            <span>BiblioTech</span>
            <div>
                <a href="<%= logado.getTipo().name().equals("ADMIN") ? "dashboard.jsp" : "home.jsp" %>">← Voltar</a>
                <a href="LogoutServlet">Sair</a>
            </div>
        </header>
        <div class="conteudo">
            <h2>Estantes por Gênero</h2>
            <% for (Estante e : estantes) {%>
            <div class="estante">
                <div class="estante-header" onclick="this.nextElementSibling.classList.toggle('aberto')">
                    <span><%= e.getGenero()%></span>
                    <span><%= e.getLivros().size()%> livro(s) ▼</span>
                </div>
                <div class="estante-corpo">
                    <% if (e.getLivros().isEmpty()) { %>
                    <p class="vazio">Nenhum livro nesta estante ainda.</p>
                    <% } else { %>
                    <table>
                        <tr><th>ID</th><th>Título</th><th>Autor</th><th>Ano</th><th>Qtd</th><th>Status</th></tr>
                                <% for (Livro l : e.getLivros()) {%>
                        <tr>
                            <td><%= l.getId()%></td>
                            <td><%= l.getTitulo()%></td>
                            <td><%= l.getAutor()%></td>
                            <td><%= l.getAnoPublicacao()%></td>
                            <td><%= l.getQuantidade()%></td>
                            <td><%= l.getStatus()%></td>
                        </tr>
                        <% } %>
                    </table>
                    <% } %>
                </div>
            </div>
            <% }%>
        </div>
    </body>
</html>